﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class UserMappingWithOtherTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "CreatedBy",
                table: "HblEntry",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "EnterBy",
                table: "HblActivity",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CreatedBy",
                table: "FileEntry",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "FileActivity",
                type: "nvarchar(450)",
                nullable: true,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_HblEntry_CreatedBy",
                table: "HblEntry",
                column: "CreatedBy");

            migrationBuilder.CreateIndex(
                name: "IX_HblActivity_EnterBy",
                table: "HblActivity",
                column: "EnterBy");

            migrationBuilder.CreateIndex(
                name: "IX_FileEntry_CreatedBy",
                table: "FileEntry",
                column: "CreatedBy");

            migrationBuilder.CreateIndex(
                name: "IX_FileActivity_UserId",
                table: "FileActivity",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_FileActivity_AspNetUsers_UserId",
                table: "FileActivity",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_FileEntry_AspNetUsers_CreatedBy",
                table: "FileEntry",
                column: "CreatedBy",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_HblActivity_AspNetUsers_EnterBy",
                table: "HblActivity",
                column: "EnterBy",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_HblEntry_AspNetUsers_CreatedBy",
                table: "HblEntry",
                column: "CreatedBy",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FileActivity_AspNetUsers_UserId",
                table: "FileActivity");

            migrationBuilder.DropForeignKey(
                name: "FK_FileEntry_AspNetUsers_CreatedBy",
                table: "FileEntry");

            migrationBuilder.DropForeignKey(
                name: "FK_HblActivity_AspNetUsers_EnterBy",
                table: "HblActivity");

            migrationBuilder.DropForeignKey(
                name: "FK_HblEntry_AspNetUsers_CreatedBy",
                table: "HblEntry");

            migrationBuilder.DropIndex(
                name: "IX_HblEntry_CreatedBy",
                table: "HblEntry");

            migrationBuilder.DropIndex(
                name: "IX_HblActivity_EnterBy",
                table: "HblActivity");

            migrationBuilder.DropIndex(
                name: "IX_FileEntry_CreatedBy",
                table: "FileEntry");

            migrationBuilder.DropIndex(
                name: "IX_FileActivity_UserId",
                table: "FileActivity");

            migrationBuilder.AlterColumn<string>(
                name: "CreatedBy",
                table: "HblEntry",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "EnterBy",
                table: "HblActivity",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "CreatedBy",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "UserId",
                table: "FileActivity",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");
        }
    }
}
