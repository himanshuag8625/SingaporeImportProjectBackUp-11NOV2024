﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class NewColumnsAddedInFileEntry : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "EtaAtFD",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HBLFreightTerm",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "MBLFreightTerm",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "EtaAtFD",
                table: "FileEntry");

            migrationBuilder.DropColumn(
                name: "HBLFreightTerm",
                table: "FileEntry");

            migrationBuilder.DropColumn(
                name: "MBLFreightTerm",
                table: "FileEntry");
        }
    }
}
