﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class HistoryTableLog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FileHistoryLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FileActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActivityId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    CurrentStatus = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EnterDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileHistoryLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FileHistoryLog_ActivityMaster_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "ActivityMaster",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_FileHistoryLog_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FileHistoryLog_FileActivity_FileActivityId",
                        column: x => x.FileActivityId,
                        principalTable: "FileActivity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HBLHistoryLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    HBLActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActivityId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CurrentStatus = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EnterBy = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    StartTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EndTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    EnterDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HBLHistoryLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_HBLHistoryLog_AspNetUsers_EnterBy",
                        column: x => x.EnterBy,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_HBLHistoryLog_HblActivity_HBLActivityId",
                        column: x => x.HBLActivityId,
                        principalTable: "HblActivity",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FileHistoryLog_ActivityId",
                table: "FileHistoryLog",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_FileHistoryLog_FileActivityId",
                table: "FileHistoryLog",
                column: "FileActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_FileHistoryLog_UserId",
                table: "FileHistoryLog",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_HBLHistoryLog_EnterBy",
                table: "HBLHistoryLog",
                column: "EnterBy");

            migrationBuilder.CreateIndex(
                name: "IX_HBLHistoryLog_HBLActivityId",
                table: "HBLHistoryLog",
                column: "HBLActivityId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FileHistoryLog");

            migrationBuilder.DropTable(
                name: "HBLHistoryLog");
        }
    }
}
