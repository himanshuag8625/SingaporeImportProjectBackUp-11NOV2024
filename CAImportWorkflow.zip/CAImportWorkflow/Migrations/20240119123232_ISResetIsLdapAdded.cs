﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class ISResetIsLdapAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PolLocationRelation");

            migrationBuilder.DropTable(
                name: "POLMaster");

            

            migrationBuilder.AddColumn<bool>(
                name: "IsLDAP",
                table: "AspNetUsers",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsReset",
                table: "AspNetUsers",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            
            migrationBuilder.DropColumn(
                name: "IsLDAP",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "IsReset",
                table: "AspNetUsers");

            migrationBuilder.CreateTable(
                name: "POLMaster",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_POLMaster", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PolLocationRelation",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LocationId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    PolId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PolLocationRelation", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PolLocationRelation_LocationMaster_LocationId",
                        column: x => x.LocationId,
                        principalTable: "LocationMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PolLocationRelation_POLMaster_PolId",
                        column: x => x.PolId,
                        principalTable: "POLMaster",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PolLocationRelation_LocationId",
                table: "PolLocationRelation",
                column: "LocationId");

            migrationBuilder.CreateIndex(
                name: "IX_PolLocationRelation_PolId",
                table: "PolLocationRelation",
                column: "PolId");
        }
    }
}
