﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class RenameSequenceInActivityMaster : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Sequance",
                table: "ThreadMaster",
                newName: "Sequence");

            migrationBuilder.RenameColumn(
                name: "Sequance",
                table: "ActivityMaster",
                newName: "Sequence");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Sequence",
                table: "ThreadMaster",
                newName: "Sequance");

            migrationBuilder.RenameColumn(
                name: "Sequence",
                table: "ActivityMaster",
                newName: "Sequance");
        }
    }
}
