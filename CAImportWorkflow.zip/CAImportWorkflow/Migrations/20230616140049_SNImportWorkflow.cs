﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class SNImportWorkflow : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Cbm",
                table: "FileEntry");

            migrationBuilder.DropColumn(
                name: "CoLoader",
                table: "FileEntry");

            migrationBuilder.DropColumn(
                name: "ContactPerson",
                table: "FileEntry");

            migrationBuilder.DropColumn(
                name: "EtaAtFD",
                table: "FileEntry");

            migrationBuilder.DropColumn(
                name: "FinalDestination",
                table: "FileEntry");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Cbm",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "CoLoader",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ContactPerson",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "EtaAtFD",
                table: "FileEntry",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "FinalDestination",
                table: "FileEntry",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
