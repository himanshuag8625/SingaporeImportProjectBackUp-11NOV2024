﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Globalization;
using System.Linq.Dynamic.Core;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Security.Claims;

namespace CAImportWorkflow.Controllers
{
    public class UserController : Controller
    {
        ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly RoleManager<Role> roleManager;
        private readonly UserManager<User> userManger;
        private readonly SignInManager<User> signInManager;
        public UserController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, UserManager<User> userManger, SignInManager<User> signInManager, RoleManager<Role> roleManager)
        {
            _ctx = ctx;
            _httpContextAccessor = httpContextAccessor;
            this.roleManager = roleManager;
            this.userManger = userManger;
            this.signInManager = signInManager;

        }

        [HttpGet]
        public IActionResult SelectRole()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["AssignedRoles"] = _ctx.UserRoles.Where(x => x.UserId == userid).Select(x => new RoleNameList
            {
                RoleId = x.RoleId,
                RoleName = _ctx.Role.Where(y => y.Id == x.RoleId).Select(x => x.Name).FirstOrDefault()

            }).OrderBy(x => x.RoleName).ToList();
            return View();
        }
        public IActionResult UserThread()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            ViewData["UserThread"] = _ctx.ThreadRelation.Include(x => x.ThreadMaster).Where(x => x.UserId == userid && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => new ThreadMaster
            {
                Id = x.ThreadMaster.Id,
                Name = x.ThreadMaster.Name,

            }).OrderBy(x => x.Name).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult RoleAction(string RoleName)
        {
            if (RoleName.ToUpper() == "ADMIN" || RoleName.ToUpper() == "SUPERVISOR" || RoleName.ToUpper() == "MANAGER")
            {
                return RedirectToAction("AdminDashboard", "Admin");
            }
            else if (RoleName.ToUpper() == "USER")
            {
                return RedirectToAction("UserThread", "User");
            }
            else
            {
                return RedirectToAction("GetItem", "Invoice");
            }

            return View();
        }

        [HttpGet]
        public IActionResult UserAction(string ThreadName)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            ViewData["ThreadName"] = _ctx.ThreadMaster.Where(x => x.Id == ThreadName).FirstOrDefault();
            ViewData["ThreadList"] = _ctx.ThreadMaster.Where(x => x.Id == ThreadName).ToList();
            ViewData["ActivityList"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.ThreadId == ThreadName).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            ViewData["HblactivityList"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.BasedOn == "HBL" && x.ThreadId == ThreadName && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).Select(x => new ActivityMaster
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                ThreadId = x.ThreadId,
                Sequence = x.Sequence
            }).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            ViewData["FileactivityList"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true && x.BasedOn == "File" && x.ThreadId == ThreadName).OrderBy(x => x.Sequence).ThenBy(x => x.Name).Select(x => new ActivityMaster
            {
                Id = x.Id,
                Name = x.Name,
                BasedOn = x.BasedOn,
                ThreadId = x.ThreadId,
                Sequence = x.Sequence
            }).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            ViewData["ActivityMappingList"] = _ctx.ActivityMapping.Include(x => x.FileActivityMaster).Where(x => x.IsActive == true && x.FileActivityMaster.BasedOn == "File" && x.FileActivityMaster.ThreadId == ThreadName).ToList();

            ViewData["Location"] = _ctx.UserLocationRelation.Include(x => x.LocationMaster).Include(x => x.User).Where(x => x.UserId == userid && x.LocationMaster.IsActive == true && x.User.IsActive == true).Select(x => new LocationMaster
            {
                Id = x.LocationMaster.Id,
                Name =x.LocationMaster.Name,

            }).ToList();

            return View();
        }

        [HttpGet]
        public JsonResult CheckHBLActivityStatus(string fileActivityId)
        {
            List<ActivityMapping> activityMappings = _ctx.ActivityMapping.Where(x => x.IsActive == true && x.FileActivityId == fileActivityId).ToList();
            return Json(activityMappings);
        }

        [HttpGet]
        public JsonResult ResetFileActivityStatus(string hblActivityId)
        {
            List<ActivityMapping> activityMappings = _ctx.ActivityMapping.Where(x => x.IsActive == true && x.HBLActivityId == hblActivityId).ToList();
            return Json(activityMappings);
        }

        static DateTime GetDate(string Column0)
        {
            DateTime dt;
            if (!DateTime.TryParseExact(Column0, "yyyy/dd/MM hh:mm:ss tt",
                       CultureInfo.InvariantCulture,
                       DateTimeStyles.None, out dt))
            {
                dt = DateTime.MinValue;
            }

            return dt;
        }

        [HttpGet]
        public JsonResult GetNextFile(string threadmasterId, string Location)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            SubmitDataViewModel submitDataViewModel = new SubmitDataViewModel();
            submitDataViewModel.HBLDataSubmit = new List<HblDataSubmitViewModel>();
            submitDataViewModel.FileActivityStatusSubmit = new List<FileActivityStatus>();
            submitDataViewModel.Activities = new List<ActivityMaster>();
            submitDataViewModel.file = new List<FileData>();
            List<HblEntry> hblEntryResult = new List<HblEntry>();
            List<FileActivity> fileActresult = new List<FileActivity>();
            List<HblActivity> hblActResult = new List<HblActivity>();
            submitDataViewModel.Activities = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
            .Where(x => x.ThreadId == threadmasterId.Trim() && x.IsActive == true && x.ThreadMaster.IsActive == true)
            .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            DateTime dtETA;
            var allocates = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User)
            .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.CurrentStatus == "WIP"
                          && x.UserId == userid && x.ActivityMaster.ThreadId == threadmasterId.Trim()
                          && x.ActivityMaster.IsActive == true && x.User.IsActive == true
                          && x.ActivityMaster.ThreadMaster.IsActive == true
                          && ((x.ActivityMaster.Name.ToLower() == "file processing" || x.ActivityMaster.Name.ToLower() == "file processing status")
                          && x.CurrentStatus != "Completed"))
            .Select(x => new
            {
                x.FileId,
                x.FileEntry.EtaAtPod,
                x.CurrentStatus
            }).Distinct().ToList();///Distinct Removed
            var allocate = allocates.OrderBy(x => x.EtaAtPod).FirstOrDefault();
            if (allocate == null)
            {
                allocates = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User)
                .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.CurrentStatus == "WIP"
                              && x.UserId == null && x.ActivityMaster.IsActive == true && x.User.IsActive == true
                              && x.ActivityMaster.ThreadMaster.IsActive == true && x.ActivityMaster.ThreadId == threadmasterId.Trim()
                              && ((x.ActivityMaster.Name.ToLower() == "file processing" || x.ActivityMaster.Name.ToLower() == "file processing status")
                              && x.CurrentStatus != "Completed"))
                .Select(x => new
                {
                    x.FileId,
                    x.FileEntry.EtaAtPod,
                    x.CurrentStatus
                }).Distinct().ToList();///Distinct Removed
                allocate = allocates.OrderBy(x => x.EtaAtPod).FirstOrDefault();
                if (allocate != null)
                {
                    List<FileActivity> fileActivityList = _ctx.FileActivity.Include(x => x.FileEntry)
                    .Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                    .Where(x => x.CurrentStatus == "WIP" && x.UserId == null && x.ActivityMaster.ThreadId == threadmasterId.Trim()
                                && x.FileId == allocate.FileId.ToString() && x.ActivityMaster.IsActive == true
                                && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true)
                    .OrderBy(x => x.FileEntry.EtaAtPod).ToList();
                    foreach (FileActivity activity in fileActivityList)
                    {
                        activity.UserId = userid;
                        activity.StartTime = DateTime.UtcNow;
                        _ctx.FileActivity.Update(activity);
                    }
                    _ctx.SaveChanges();

                    allocates = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User)
                                    .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                    .Where(x => x.CurrentStatus == "WIP" && x.ActivityMaster.IsActive == true
                                                && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true
                                                && x.UserId == userid && x.ActivityMaster.ThreadId == threadmasterId.Trim())
                                    .Select(x => new
                                    {
                                        x.FileId,
                                        x.FileEntry.EtaAtPod,
                                        x.CurrentStatus
                                    }).Distinct().ToList(); ///Distinct Removed
                    allocate = allocates.OrderBy(x => x.EtaAtPod).FirstOrDefault();

                }
            }

            if (allocate != null)
            {
                submitDataViewModel.file = _ctx.FileEntry.Include(x => x.User)
                                            .Where(x => x.Id == allocate.FileId.ToString() && x.User.IsActive == true)
                                            .Select(x => new FileData
                                            {
                                                FileNo = x.FileNo,
                                                Id = x.Id,
                                                ContainerNo = x.ContainerNo,
                                                pol = x.Pol,
                                                pod = x.Pod,
                                                ETAatPOD = x.EtaAtPod,
                                                Hblcount = x.Hblcount,
                                                ShippingLine = x.ShippingLine
                                            }).ToList();
                fileActresult = _ctx.FileActivity.Include(x => x.User).Include(x => x.ActivityMaster)
                                .ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == submitDataViewModel.file[0].Id.ToString()
                                                    && x.ActivityMaster.IsActive == true && x.User.IsActive == true
                                                    && x.ActivityMaster.ThreadMaster.IsActive == true
                                                    && x.ActivityMaster.ThreadId == threadmasterId.Trim()
                                                    && ((x.ActivityMaster.Name.ToLower() == "file processing" || x.ActivityMaster.Name.ToLower() == "file processing status")
                                                    && x.CurrentStatus != "Completed")).ToList();
                foreach (FileActivity fileActivity in fileActresult)
                {
                    fileActivity.StartTime = DateTime.UtcNow;
                    _ctx.FileActivity.Update(fileActivity);

                    submitDataViewModel.FileActivityStatusSubmit.Add(new FileActivityStatus
                    {
                        ActivityId = fileActivity.ActivityId.ToString(),
                        CurrentStatus = fileActivity.CurrentStatus,
                        Comments = fileActivity.Comment == null ? "" : fileActivity.Comment
                    });
                }

                hblEntryResult = _ctx.HblEntry.Where(x => x.FileGuidId == submitDataViewModel.file[0].Id.ToString()).ToList();
                foreach (HblEntry hbl in hblEntryResult)
                {
                    hblActResult = _ctx.HblActivity.Include(x => x.User).Include(y => y.ActivityMaster)
                                    .ThenInclude(x => x.ThreadMaster).Where(x => x.HblId == hbl.Id
                                        && x.ActivityMaster.IsActive == true && x.User.IsActive == true
                                        && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();
                    List<HBLActivityStatus> hBLActivityStatuses = new List<HBLActivityStatus>();
                    foreach (HblActivity hblActivity in hblActResult)
                    {
                        HBLActivityStatus hBLActivityStatus = new HBLActivityStatus
                        {
                            ActivityId = hblActivity.ActivityId.ToString(),
                            Status = hblActivity.CurrentStatus,
                            HblComments = hblActivity.Comment
                        };

                        hBLActivityStatuses.Add(hBLActivityStatus);
                    }

                    if (hBLActivityStatuses.Count > 0)
                    {
                        HblDataSubmitViewModel hblDataSubmitViewModel = new HblDataSubmitViewModel
                        {
                            HblNo = hbl.Hblno,
                            PLD = hbl.PLD,
                            HBLType = hbl.HBLType,
                            IsDap = hbl.IsDap == true ? "Yes" : "No",
                            HBLActivityStatuses = hBLActivityStatuses
                        };
                        submitDataViewModel.HBLDataSubmit.Add(hblDataSubmitViewModel);

                    }
                    else
                    {
                        HblDataSubmitViewModel hblDataSubmitViewModel = new HblDataSubmitViewModel
                        {
                            HblNo = hbl.Hblno,
                            PLD = hbl.PLD,
                            HBLType = hbl.HBLType,
                            IsDap = hbl.IsDap == true ? "Yes" : "No",
                        };
                        submitDataViewModel.HBLDataSubmit.Add(hblDataSubmitViewModel);
                    }
                }
            }
            return Json(submitDataViewModel);
            return Json("Failed");
        }

        [HttpPost]
        public JsonResult SaveData(SubmitDataViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);           
            if (model.HBLDataSubmit != null)
            {
                foreach (HblDataSubmitViewModel hblvm in model.HBLDataSubmit)
                {
                    string hblId = "";

                    if (hblvm.HblNo != null && hblvm.HblNo.Trim() != "")
                    {
                        HblEntry hblEntry = _ctx.HblEntry.Where(x => x.Hblno == hblvm.HblNo).FirstOrDefault();
                        if (hblEntry == null)
                        {
                            HblEntry hblentry = new HblEntry
                            {
                                Id = Guid.NewGuid().ToString(),
                                FileGuidId = model.file[0].Id,
                                Hblno = hblvm.HblNo,
                                PLD = hblvm.PLD,
                                HBLType = hblvm.HBLType,
                                IsDap = hblvm.IsDap.ToUpper() == "YES" || hblvm.IsDap.ToUpper() == "TRUE" ? true : false,
                                CreatedBy = userid,
                                CreatedDate = DateTime.Now.ToUniversalTime(),
                            };

                            hblId = hblentry.Id;

                            _ctx.HblEntry.Add(hblentry);
                        }
                        else
                        {
                            hblId = hblEntry.Id;
                            hblEntry.Hblno = hblvm.HblNo;
                            hblEntry.PLD = hblvm.PLD;
                            hblEntry.HBLType = hblvm.HBLType;
                            hblEntry.IsDap = hblvm.IsDap.ToUpper() == "YES" || hblvm.IsDap.ToUpper() == "TRUE" ? true : false;
                            _ctx.HblEntry.Update(hblEntry);
                        }

                        foreach (HBLActivityStatus status in hblvm.HBLActivityStatuses)
                        {
                            if (status.Status != "" && !status.Status.Contains("Select"))
                            {
                                HblActivity hblact = _ctx.HblActivity.Include(x => x.User)
                                                        .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                                        .Where(x => x.ActivityId == status.ActivityId && x.HblId == hblId 
                                                                    && x.ActivityMaster.IsActive == true && x.User.IsActive == true 
                                                                    && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
                                if (hblact == null)
                                {
                                    HblActivity hblActivity = new HblActivity
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        HblId = hblId,
                                        ActivityId = status.ActivityId,
                                        CurrentStatus = status.Status,
                                        Comment = status.HblComments,
                                        StartTime = status.StartTime,
                                        EndTime = DateTime.Now.ToUniversalTime(),
                                        EnterBy = userid,
                                        EnterDate = DateTime.Now.ToUniversalTime()
                                    };
                                    _ctx.HblActivity.Add(hblActivity);
                                }
                                else
                                {
                                    hblact.StartTime = status.StartTime;
                                    hblact.CurrentStatus = status.Status;
                                    hblact.Comment = status.HblComments;
                                    hblact.EndTime = DateTime.Now.ToUniversalTime();

                                    _ctx.HblActivity.Update(hblact);
                                }
                            }
                            else
                            {
                                HblActivity hblact = _ctx.HblActivity.Include(x => x.User).Include(x => x.ActivityMaster)
                                                        .ThenInclude(x => x.ThreadMaster)
                                                        .Where(x => x.ActivityId == status.ActivityId 
                                                                    && x.HblId == hblId && x.ActivityMaster.IsActive == true
                                                                    && x.User.IsActive == true 
                                                                    && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
                                if (hblact == null)
                                {
                                    HblActivity hblActivity = new HblActivity
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        HblId = hblId,
                                        ActivityId = status.ActivityId,
                                        CurrentStatus = "WIP",
                                        Comment = status.HblComments,
                                        StartTime = status.StartTime,
                                        EndTime = DateTime.Now.ToUniversalTime(),
                                        EnterBy = userid,
                                        EnterDate = DateTime.Now.ToUniversalTime()
                                    };
                                    _ctx.HblActivity.Add(hblActivity);
                                }
                                else
                                {
                                    hblact.StartTime = status.StartTime;
                                    hblact.CurrentStatus = "WIP";
                                    hblact.Comment = status.HblComments;
                                    hblact.EndTime = DateTime.Now.ToUniversalTime();
                                    _ctx.HblActivity.Update(hblact);
                                }
                                _ctx.SaveChanges();
                            }
                        }
                    }
                    _ctx.SaveChanges();
                }


            }

            FileEntry fileEntry = _ctx.FileEntry.Where(x => x.Id == model.file[0].Id).FirstOrDefault();
            if (fileEntry != null)
            {
                fileEntry.FileNo = model.file[0].FileNo;
                fileEntry.ContainerNo = model.file[0].ContainerNo;
                fileEntry.EtaAtPod = model.file[0].ETAatPOD;
                fileEntry.Pol = model.file[0].pol;
                fileEntry.Pod = model.file[0].pod;
                _ctx.FileEntry.Update(fileEntry);

                string firstActivity = "";
                bool flag = false;

                foreach (var fileActivityStatus in model.FileActivityStatusSubmit)
                {
                    if (!fileActivityStatus.CurrentStatus.Contains("Select"))
                    {
                        if (!flag)
                        {
                            firstActivity = fileActivityStatus.ActivityId;
                            flag = true;
                        }

                        FileActivity fileActivity = _ctx.FileActivity.Include(x => x.ActivityMaster)
                                                    .Where(x => x.ActivityId == fileActivityStatus.ActivityId 
                                                                && x.FileId == model.file[0].Id 
                                                                && x.ActivityMaster.IsActive == true).FirstOrDefault();
                        if (fileActivity == null)
                        {
                            FileActivity fileActivities = new FileActivity
                            {
                                Id = Guid.NewGuid().ToString(),
                                ActivityId = fileActivityStatus.ActivityId,
                                UserId = userid,
                                StartTime = Convert.ToDateTime(fileActivityStatus.StartTime),
                                CurrentStatus = fileActivityStatus.CurrentStatus,
                                Comment = fileActivityStatus.Comments,
                                Pages = fileActivityStatus.Pages,
                                EndTime = DateTime.Now.ToUniversalTime(),
                                EnterDate = DateTime.Now.ToUniversalTime(),
                            };
                            _ctx.FileActivity.Add(fileActivities);
                            _ctx.SaveChanges();
                        }
                        else
                        {
                            if(fileActivity.CurrentStatus == "Completed") 
                            {
                                fileActivity.CurrentStatus = fileActivityStatus.CurrentStatus;
                                fileActivity.Comment = fileActivityStatus.Comments;
                                fileActivity.Pages = fileActivityStatus.Pages;
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                            else
                            {
                                if (fileActivityStatus.CurrentStatus != "Completed")
                                {
                                    fileActivity.CurrentStatus = fileActivityStatus.CurrentStatus;
                                    fileActivity.Comment = fileActivityStatus.Comments;
                                    fileActivity.Pages = fileActivityStatus.Pages;
                                    _ctx.FileActivity.Update(fileActivity);
                                }
                                else
                                {
                                    fileActivity.StartTime = Convert.ToDateTime(fileActivityStatus.StartTime);
                                    fileActivity.CurrentStatus = fileActivityStatus.CurrentStatus;
                                    fileActivity.Comment = fileActivityStatus.Comments;
                                    fileActivity.Pages = fileActivityStatus.Pages;
                                    fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                    _ctx.FileActivity.Update(fileActivity);
                                }
                                
                                _ctx.SaveChanges();
                            }
                            
                        }
                        _ctx.SaveChanges();
                    }
                    else
                    {
                        if (!flag)
                        {
                            firstActivity = fileActivityStatus.ActivityId;
                            flag = true;
                        }

                        FileActivity fileActivity = _ctx.FileActivity.Include(x => x.ActivityMaster)
                                                    .Where(x => x.ActivityId == fileActivityStatus.ActivityId 
                                                    && x.FileId == model.file[0].Id 
                                                    && x.ActivityMaster.IsActive == true).FirstOrDefault();
                        if (fileActivity == null)
                        {
                            FileActivity fileActivities = new FileActivity
                            {
                                Id = Guid.NewGuid().ToString(),
                                ActivityId = fileActivityStatus.ActivityId,
                                UserId = userid,
                                StartTime = Convert.ToDateTime(fileActivityStatus.StartTime),
                                CurrentStatus = "WIP",
                                Comment = fileActivityStatus.Comments,
                                Pages = fileActivityStatus.Pages,
                                EnterDate = DateTime.Now.ToUniversalTime(),
                            };
                            _ctx.FileActivity.Add(fileActivities);
                            _ctx.SaveChanges();
                        }
                        else
                        {
                            fileActivity.StartTime = Convert.ToDateTime(fileActivityStatus.StartTime);
                            fileActivity.CurrentStatus = "WIP";
                            fileActivity.Comment = fileActivityStatus.Comments;
                            fileActivity.Pages = fileActivityStatus.Pages;
                            _ctx.FileActivity.Update(fileActivity);
                            _ctx.SaveChanges();
                        }
                        _ctx.SaveChanges();
                    }
                }

                var CurrentThreadId = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                        .Where(x => x.Id == firstActivity && x.IsActive == true && x.ThreadMaster.IsActive == true)
                                        .Select(x => x.ThreadMaster).FirstOrDefault();

                ThreadMaster threadMaster = _ctx.ThreadMaster.Include(x => x.ActivityMaster
                                            .Where(y => y.BasedOn == "File" && y.IsActive == true))
                                            .Where(x => x.Sequence > CurrentThreadId.Sequence && x.IsActive == true)
                                            .OrderBy(i => i.Sequence).FirstOrDefault();
                if (threadMaster != null && threadMaster.ActivityMaster.Count > 0)
                {
                    foreach (ActivityMaster activity in threadMaster.ActivityMaster.Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true).ToList())
                    {
                        FileActivity fileNextActivity = _ctx.FileActivity.Include(x => x.User)
                                                        .Include(x => x.ActivityMaster)
                                                        .ThenInclude(x => x.ThreadMaster)
                                                        .Where(x => x.ActivityId == activity.Id && x.FileId == model.file[0].Id 
                                                                    && x.ActivityMaster.IsActive == true && x.User.IsActive == true 
                                                                    && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
                        if (fileNextActivity == null)
                        {
                            _ctx.FileActivity.Add(new FileActivity
                            {
                                Id = Guid.NewGuid().ToString(),
                                FileId = model.file[0].Id,
                                ActivityId = activity.Id,
                                CurrentStatus = "WIP",
                                Comment = null,
                                UserId = null,
                                EnterDate = DateTime.Now.ToUniversalTime(),
                                StartTime = null,
                                EndTime = null
                            });
                        }
                    }
                    _ctx.SaveChanges();
                }
            }
            return Json("Success");
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                .Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true)
                                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                .Where(x => x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true)
                                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            foreach (var item in fileActivity)
            {
                userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                {
                    Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                    UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                    WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                    Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                });
            }


            foreach (var item in hblActivity)
            {
                userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                {
                    Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                    UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                    WIP = _ctx.HblActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Completed = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    CompletedWithQuery = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Pending = _ctx.HblActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Query = _ctx.HblActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    Total = _ctx.HblActivity.Where(x => x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                });
            }
            return View(userActivityStatus);
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                .Where(x => x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true)
                                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                .Where(x => x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true)
                                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            if (StartDate != null && EndDate != null)
            {
                var fileActivityList = _ctx.FileActivity.Where(x => x.EndTime != null && x.EndTime.Value.Date >= StartDate.Value.Date && x.EndTime.Value.Date <= EndDate.Value.Date).ToList();
                var hblActivityList = _ctx.HblActivity.Where(x => x.EndTime != null && x.EndTime.Value.Date >= StartDate.Value.Date && x.EndTime.Value.Date <= EndDate.Value.Date).ToList();
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }

                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = hblActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Completed = hblActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        CompletedWithQuery = hblActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Pending = hblActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Query = hblActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Total = hblActivityList.Where(x => x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    });
                }
            }
            else
            {
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }


                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.ThreadMaster.IsActive == true && x.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.HblActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Completed = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        CompletedWithQuery = _ctx.HblActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Pending = _ctx.HblActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Query = _ctx.HblActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                        Total = _ctx.HblActivity.Where(x => x.ActivityId == item.Id && x.EnterBy == userid).Count(),
                    });
                }
            }
            return Json(userActivityStatus);
        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            UserActivityStatusViewModel userActivityStatus = new UserActivityStatusViewModel();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                .Where(x => x.BasedOn == "File" && x.IsActive == true && x.ThreadMaster.IsActive == true)
                                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                .Where(x => x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true)
                                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            if (StartDate != null && EndDate != null)
            {
                var fileActivityList = _ctx.FileActivity
                    .Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date 
                                && x.EnterDate.Value.Date <= EndDate.Value.Date).ToList();
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }

                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault(),
                        WIP = fileActivityList.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = fileActivityList.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = fileActivityList.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = fileActivityList.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = fileActivityList.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = fileActivityList.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }
            else
            {
                foreach (var item in fileActivity)
                {
                    userActivityStatus.GetFileActivityStatus.Add(new FileActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "File" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }


                foreach (var item in hblActivity)
                {
                    userActivityStatus.GetHBLActivityStatus.Add(new HBLActivityStatusList
                    {
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == item.Id && x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        UserId = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault(),
                        WIP = _ctx.FileActivity.Where(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Completed = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        CompletedWithQuery = _ctx.FileActivity.Where(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Pending = _ctx.FileActivity.Where(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Query = _ctx.FileActivity.Where(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == userid).Count(),
                        Total = _ctx.FileActivity.Where(x => x.ActivityId == item.Id && x.UserId == userid).Count(),
                    });
                }
            }

            var fileStatus = userActivityStatus.GetFileActivityStatus.Select(x => new FileStatusList
            {
                Activity = x.Activity,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed

            }).ToList();

            var hblStatus = userActivityStatus.GetHBLActivityStatus.Select(x => new HBLStatusList
            {
                Activity = x.Activity,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed

            }).ToList();
            DataTable FileActivityStatus = ToDataTable(fileStatus);
            DataTable HBLActivityStatus = ToDataTable(hblStatus);

            using (XLWorkbook wb = new XLWorkbook())
            {
                FileActivityStatus.TableName = "File Activity Status";
                HBLActivityStatus.TableName = "HBL Activity Status";
                var wsData = wb.Worksheets.Add(FileActivityStatus);
                var ws = wb.Worksheets.Add(HBLActivityStatus);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"UserActivityStatus-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true && x.BasedOn == "File").OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status, string startDate, string fileNo, string containerNo, string hblNo)
        {
            DateTime DateTime = Convert.ToDateTime(startDate);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            var userName = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault();
            var activityDV = _ctx.ActivityMaster
                            .Where(x => (x.Name.ToUpper() == "DV" || x.Name.ToUpper() == "DIGIVIEW") 
                                        && x.IsActive == true && x.BasedOn == "File").Select(x => x.Id).FirstOrDefault();
            var activityNOA = _ctx.ActivityMaster
                                .Where(x => (x.Name.ToUpper() == "NOA" || x.Name.ToUpper() == "NOA") 
                                            && x.IsActive == true && x.BasedOn == "File").Select(x => x.Id).FirstOrDefault();
            if (activityType == "HBL")
            {

                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster)
                    .ThenInclude(x => x.ThreadMaster).Include(x => x.User)
                    .Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid)
                    .Include(x => x.HblEntry.FileGuid.FileActivity)
                    .Where(x => x.ActivityId != activityDV && x.ActivityId != activityNOA)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment == null ? "" : x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        Eta = x.HblEntry.FileGuid.EtaAtPod,
                        CreatedDate = x.HblEntry.CreatedDate,
                        FileNo = x.HblEntry.FileGuid.FileNo == null ? "" : x.HblEntry.FileGuid.FileNo,
                        FileId = x.HblEntry.FileGuid.Id,
                        ContainerNo = x.HblEntry.FileGuid.ContainerNo == null ? "" : x.HblEntry.FileGuid.ContainerNo,
                        hblNo = x.HblEntry.Hblno,
                        Id = x.HblEntry.FileGuidId,
                        PLD = x.HblEntry.PLD,
                        HBLType = x.HblEntry.HBLType,
                        HBLId = x.HblId,
                        UserId = x.User.UserName,
                        Activity = x.ActivityId,
                        hblCount = x.HblEntry.FileGuid.Hblcount,
                        IsEdi = x.HblEntry.FileGuid.IsEdi,
                        Remarks = x.HblEntry.FileGuid.ShippingLine,
                        StartTime = x.StartTime

                    }).ToList();

            }
            else
            {

                fileEntryData = _ctx.FileActivity.Where(x => x.ActivityId != activityDV && x.ActivityId != activityNOA).Include(x => x.ActivityMaster).Include(x => x.FileEntry.HblEntry).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    CreatedDate = x.FileEntry.CreatedDate,
                    FileNo = x.FileEntry.FileNo == null ? "" : x.FileEntry.FileNo,
                    FileId = x.FileEntry.Id,
                    Eta = x.FileEntry.EtaAtPod,
                    ContainerNo = x.FileEntry.ContainerNo == null ? "" : x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    IsEdi = x.FileEntry.IsEdi,
                    Remarks = x.FileEntry.ShippingLine,
                    HBLId = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Id).FirstOrDefault(),
                    UserId = x.User.UserName,
                    Pages = x.Pages == null ? 0 : x.Pages,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime,
                    Activity = x.ActivityId,
                    hblNo = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Hblno).FirstOrDefault(),

                }).ToList();
            }

            totalRecord = fileEntryData.Count();

            IQueryable<FileActivityDataList> SortedData = fileEntryData.AsQueryable();
            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileNo.Trim());

            }

            if (!string.IsNullOrEmpty(containerNo))
            {
                SortedData = SortedData.Where(x => x.ContainerNo == containerNo.Trim());

            }

            if (!string.IsNullOrEmpty(hblNo))
            {
                SortedData = SortedData.Where(x => x.hblNo == hblNo.Trim());

            }

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }

            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--select--")
            {
                SortedData = SortedData.Where(x => x.UserId == userName.Trim());

            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());
            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }

            if (sortColumn == "HBL")
            {
                sortColumn = "hblNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            else if (sortColumn == "activityName")
            {
                sortColumn = "activityId";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (sortColumn == "createdDate")
            {
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "createdDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
                skip = skip,
                pageSize = pageSize,
            };

            return Json(returnObj);
        }
        
        [HttpGet]
        public IActionResult GetDVActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                        .Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true && x.BasedOn == "File")
                                        .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetDVActivityFileData(string activity, string activityType, string status, string startDate, string fileNo, string containerNo, string hblNo)
        {
            DateTime DateTime = Convert.ToDateTime(startDate);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            var userName = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault();
            var activityId = _ctx.ActivityMaster
                            .Where(x => (x.Name.ToUpper() == "DV" || x.Name.ToUpper() == "DIGIVIEW") 
                                        && x.IsActive == true && x.BasedOn == "File").Select(x => x.Id).FirstOrDefault();
            if (activityType == "HBL")
            {

                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                    .Include(x => x.User).Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid)
                    .Include(x => x.HblEntry.FileGuid.FileActivity).Where(x => x.ActivityId == activityId)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment == null ? "" : x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        Eta = x.HblEntry.FileGuid.EtaAtPod,
                        CreatedDate = x.HblEntry.CreatedDate,
                        FileNo = x.HblEntry.FileGuid.FileNo == null ? "" : x.HblEntry.FileGuid.FileNo,
                        FileId = x.HblEntry.FileGuid.Id,
                        ContainerNo = x.HblEntry.FileGuid.ContainerNo == null ? "" : x.HblEntry.FileGuid.ContainerNo,
                        hblNo = x.HblEntry.Hblno,
                        Id = x.HblEntry.FileGuidId,
                        PLD = x.HblEntry.PLD,
                        HBLType = x.HblEntry.HBLType,
                        HBLId = x.HblId,
                        UserId = x.User.UserName,
                        Activity = x.ActivityId,
                        hblCount = x.HblEntry.FileGuid.Hblcount,
                        IsEdi = x.HblEntry.FileGuid.IsEdi,
                        Remarks = x.HblEntry.FileGuid.ShippingLine,
                        StartTime = x.StartTime

                    }).ToList();

            }
            else
            {

                fileEntryData = _ctx.FileActivity.Where(x => x.ActivityId == activityId).Include(x => x.FileEntry).Include(x => x.ActivityMaster).Include(x => x.FileEntry.HblEntry).Where(x => x.ActivityId == activityId).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    CreatedDate = x.FileEntry.CreatedDate,
                    FileNo = x.FileEntry.FileNo == null ? "" : x.FileEntry.FileNo,
                    FileId = x.FileEntry.Id,
                    Eta = x.FileEntry.EtaAtPod,
                    ContainerNo = x.FileEntry.ContainerNo == null ? "" : x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    IsEdi = x.FileEntry.IsEdi,
                    Remarks = x.FileEntry.ShippingLine,
                    HBLId = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Id).FirstOrDefault(),
                    UserId = x.User.UserName,
                    Pages = x.Pages == null ? 0 : x.Pages,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime,
                    Activity = x.ActivityId,
                    hblNo = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Hblno).FirstOrDefault(),

                }).ToList();
            }

            totalRecord = fileEntryData.Count();

            IQueryable<FileActivityDataList> SortedData = fileEntryData.AsQueryable();
            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileNo.Trim());

            }

            if (!string.IsNullOrEmpty(containerNo))
            {
                SortedData = SortedData.Where(x => x.ContainerNo == containerNo.Trim());

            }

            if (!string.IsNullOrEmpty(hblNo))
            {
                SortedData = SortedData.Where(x => x.hblNo == hblNo.Trim());

            }

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());

            }

            //if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--select--")
            //{
            //    SortedData = SortedData.Where(x => x.UserId == userName.Trim());

            //}

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());
            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }

            if (sortColumn == "HBL")
            {
                sortColumn = "hblNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            else if (sortColumn == "activityName")
            {
                sortColumn = "activityId";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (sortColumn == "createdDate")
            {
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "createdDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
                skip = skip,
                pageSize = pageSize,
            };

            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult GetNOAActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true && x.BasedOn == "File").OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult GetNOAActivityFileData(string activity, string activityType, string status, string startDate, string fileNo, string containerNo, string hblNo)
        {
            DateTime DateTime = Convert.ToDateTime(startDate);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileEntryData = new List<FileActivityDataList>();
            var userName = _ctx.User.Where(x => x.Id == userid && x.IsActive == true).Select(x => x.UserName).FirstOrDefault();
            var activityId = _ctx.ActivityMaster.Where(x => (x.Name.ToUpper() == "NOA" || x.Name.ToUpper() == "NOA") && x.IsActive == true && x.BasedOn == "File").Select(x => x.Id).FirstOrDefault();
            if (activityType == "HBL")
            {
                fileEntryData = _ctx.HblActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.User).Include(x => x.HblEntry)
                    .Include(x => x.HblEntry.FileGuid).Include(x => x.HblEntry.FileGuid.FileActivity).Where(x => x.ActivityId == activityId)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment == null ? "" : x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        Eta = x.HblEntry.FileGuid.EtaAtPod,
                        CreatedDate = x.HblEntry.CreatedDate,
                        FileNo = x.HblEntry.FileGuid.FileNo == null ? "" : x.HblEntry.FileGuid.FileNo,
                        FileId = x.HblEntry.FileGuid.Id,
                        ContainerNo = x.HblEntry.FileGuid.ContainerNo == null ? "" : x.HblEntry.FileGuid.ContainerNo,
                        hblNo = x.HblEntry.Hblno,
                        Id = x.HblEntry.FileGuidId,
                        PLD = x.HblEntry.PLD,
                        HBLType = x.HblEntry.HBLType,
                        HBLId = x.HblId,
                        UserId = x.User.UserName,
                        Activity = x.ActivityId,
                        hblCount = x.HblEntry.FileGuid.Hblcount,
                        IsEdi = x.HblEntry.FileGuid.IsEdi,
                        Remarks = x.HblEntry.FileGuid.ShippingLine,
                        StartTime = x.StartTime

                    }).ToList();

            }
            else
            {
                fileEntryData = _ctx.FileActivity.Where(x => x.ActivityId == activityId).Include(x => x.ActivityMaster).Include(x => x.FileEntry.HblEntry).Where(x => x.ActivityId == activityId).Select(x => new FileActivityDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    BasedOn = x.ActivityMaster.BasedOn,
                    Comment = x.Comment == null ? "" : x.Comment,
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime,
                    EnterDate = x.EnterDate,
                    CreatedDate = x.FileEntry.CreatedDate,
                    FileNo = x.FileEntry.FileNo == null ? "" : x.FileEntry.FileNo,
                    FileId = x.FileEntry.Id,
                    Eta = x.FileEntry.EtaAtPod,
                    ContainerNo = x.FileEntry.ContainerNo == null ? "" : x.FileEntry.ContainerNo,
                    Id = x.FileId,
                    IsEdi = x.FileEntry.IsEdi,
                    Remarks = x.FileEntry.ShippingLine,
                    HBLId = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Id).FirstOrDefault(),
                    UserId = x.User.UserName,
                    Pages = x.Pages == null ? 0 : x.Pages,
                    hblCount = x.FileEntry.Hblcount,
                    StartTime = x.StartTime,
                    Activity = x.ActivityId,
                    hblNo = x.FileEntry.HblEntry.Where(y => y.FileGuidId == x.FileId).Select(y => y.Hblno).FirstOrDefault(),

                }).ToList();
            }

            totalRecord = fileEntryData.Count();

            IQueryable<FileActivityDataList> SortedData = fileEntryData.AsQueryable();
            if (!string.IsNullOrEmpty(fileNo))
            {
                SortedData = SortedData.Where(x => x.FileNo == fileNo.Trim());
            }

            if (!string.IsNullOrEmpty(containerNo))
            {
                SortedData = SortedData.Where(x => x.ContainerNo == containerNo.Trim());
            }

            if (!string.IsNullOrEmpty(hblNo))
            {
                SortedData = SortedData.Where(x => x.hblNo == hblNo.Trim());
            }

            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
            {
                SortedData = SortedData.Where(x => x.BasedOn == activityType.Trim());
            }

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
            {
                SortedData = SortedData.Where(x => x.ActivityId == activity.Trim());
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                SortedData = SortedData.Where(x => x.CurrentStatus == status.Trim());
            }
            else
            {
                SortedData = SortedData.Where(x => x.CurrentStatus != "Completed".Trim());
            }

            if (sortColumn == "HBL")
            {
                sortColumn = "hblNo";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }
            else if (sortColumn == "activityName")
            {
                sortColumn = "activityId";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (sortColumn == "createdDate")
            {
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                sortColumn = "createdDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = SortedData.Count(),
                data = SortedData,
                skip = skip,
                pageSize = pageSize,
            };

            return Json(returnObj);
        }


        public IActionResult GetActivityHBLData(string fileId, string fileNo, string activityId, string status, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var fileActivity = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User)
                                .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                .Where(x => x.FileEntry.Id == fileId && x.ActivityId == activityId).FirstOrDefault();

            var hblEntry = _ctx.HblActivity.Include(x => x.HblEntry)
                            .Include(x => x.ActivityMaster).Include(x => x.User)
                            .Select(x => new HBLActivityDataList
                            {
                                Id = x.Id,
                                Hblno = x.HblEntry.Hblno,
                                FileGuidId = x.HblEntry.FileGuidId,
                                HBLId = x.HblId,
                                IsDap = x.HblEntry.IsDap == true ? "Yes" : "No",
                                CreatedDate = x.EnterDate,
                                BasedOn = x.ActivityMaster.BasedOn,
                                CreatedBy = x.HblEntry.User.UserName,
                                Comment = x.Comment == null ? "" : x.Comment,
                                CurrentStatus = x.CurrentStatus,
                                StartTime = x.StartTime,
                                EndTime = x.EndTime,
                                EnterBy = x.EnterBy,
                                ActivityId = x.ActivityMaster.Name,
                                Activity = x.ActivityId,
                                PLD = x.HblEntry.PLD,
                                HBLType = x.HblEntry.HBLType,
                            }).ToList();


            var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster)
                                    .Where(x => x.FileActivityId == fileActivity.ActivityId)
                                    .Select(x => x.HBLActivityId).FirstOrDefault();

            if (hblEntry != null)
            {
                hblEntry = hblEntry.Where(x => x.Activity == HBLActivityMapId && x.FileGuidId == fileActivity.FileId).ToList();
            }
            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.EnterBy == userid).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status == "Completed")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == "Completed").ToList();
            }
            else
            {
                hblEntry = hblEntry.ToList();
            }
            return Json(hblEntry);
        }
        public IActionResult GetDVActivityHBLData(string fileId, string fileNo, string activityId, string status, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var fileActivity = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User)
                                .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                .Where(x => x.FileEntry.Id == fileId && x.ActivityId == activityId).FirstOrDefault();

            var hblEntry = _ctx.HblActivity.Include(x => x.HblEntry)
                            .Include(x => x.ActivityMaster).Include(x => x.User)
                            .Select(x => new HBLActivityDataList
                            {
                                Id = x.Id,
                                Hblno = x.HblEntry.Hblno,
                                FileGuidId = x.HblEntry.FileGuidId,
                                HBLId = x.HblId,
                                IsDap = x.HblEntry.IsDap == true ? "Yes" : "No",
                                CreatedDate = x.EnterDate,
                                BasedOn = x.ActivityMaster.BasedOn,
                                CreatedBy = x.HblEntry.User.UserName,
                                Comment = x.Comment == null ? "" : x.Comment,
                                CurrentStatus = x.CurrentStatus,
                                StartTime = x.StartTime,
                                EndTime = x.EndTime,
                                EnterBy = x.EnterBy,
                                ActivityId = x.ActivityMaster.Name,
                                Activity = x.ActivityId,
                            }).ToList();


            var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster)
                                    .Where(x => x.FileActivityId == fileActivity.ActivityId)
                                    .Select(x => x.HBLActivityId).FirstOrDefault();

            if (hblEntry != null)
            {
                hblEntry = hblEntry.Where(x => x.Activity == HBLActivityMapId && x.FileGuidId == fileActivity.FileId).ToList();
            }
            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.EnterBy == userid).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status == "Completed")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == "Completed").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }
            return Json(hblEntry);
        }
        public IActionResult GetNOAActivityHBLData(string fileId, string fileNo, string activityId, string status, string startDate)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var fileActivity = _ctx.FileActivity.Include(x => x.FileEntry)
                                .Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                .Where(x => x.FileEntry.Id == fileId && x.ActivityId == activityId).FirstOrDefault();

            var hblEntry = _ctx.HblActivity.Include(x => x.HblEntry)
                            .Include(x => x.ActivityMaster).Include(x => x.User)
                            .Select(x => new HBLActivityDataList
                            {
                                Id = x.Id,
                                Hblno = x.HblEntry.Hblno,
                                FileGuidId = x.HblEntry.FileGuidId,
                                HBLType = x.HblEntry.HBLType,
                                HBLId = x.HblId,
                                IsDap = x.HblEntry.IsDap == true ? "Yes" : "No",
                                CreatedDate = x.EnterDate,
                                BasedOn = x.ActivityMaster.BasedOn,
                                CreatedBy = x.HblEntry.User.UserName,
                                Comment = x.Comment == null ? "" : x.Comment,
                                CurrentStatus = x.CurrentStatus,
                                StartTime = x.StartTime,
                                EndTime = x.EndTime,
                                EnterBy = x.EnterBy,
                                ActivityId = x.ActivityMaster.Name,
                                Activity = x.ActivityId,
                            }).ToList();


            var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster)  
                                    .Where(x => x.FileActivityId == fileActivity.ActivityId)
                                    .Select(x => x.HBLActivityId).FirstOrDefault();

            if (hblEntry != null)
            {
                hblEntry = hblEntry.Where(x => x.Activity == HBLActivityMapId && x.FileGuidId == fileActivity.FileId).ToList();
            }
            if (!string.IsNullOrEmpty(userid) && userid != "none" && userid != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.EnterBy == userid).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status != "--select--")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == status && x.HBLType == "Local").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == "Completed" && x.HBLType == "Local").ToList();
            }
            return Json(hblEntry);
        }

        public IActionResult GetActivityType(string fileType)
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                                        .Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true)
                                        .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                            .Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true)
                            .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string status, string comment, string startDate, int pages)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            // Check if HBL Entry exists
            HblEntry hblEntry = _ctx.HblEntry.FirstOrDefault(x => x.Hblno.Trim() == model.Hblno.Trim());
            if (hblEntry == null)
            {
                // If HBL Entry doesn't exist, create a new one
                hblEntry = new HblEntry
                {
                    FileGuidId = model.Id,
                    Hblno = model.Hblno.Trim(),
                    PLD = model.PLD.Trim(),
                    HBLType = model.HBLType.Trim(),
                    IsDap = model.IsDap.Trim().ToLower() == "yes" ? true : false,
                    CreatedBy = userid,
                    CreatedDate = DateTime.UtcNow
                };
                _ctx.HblEntry.Add(hblEntry);
                _ctx.SaveChanges();
            }

            // Get the HBL Activity based on HBL Entry Id and Activity Id
            var hblActivity = _ctx.HblActivity.Include(x => x.HblEntry)
                                .Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                .Where(x => x.HblId == hblEntry.Id && x.ActivityId == model.Activity 
                                            && x.ActivityMaster.BasedOn == model.BasedOn && x.ActivityMaster.IsActive == true 
                                            && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.User)
                                    .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                    .Where(x => x.HblEntry.FileGuidId == model.Id && x.ActivityMaster.IsActive == true 
                                                && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

            if (hblActivity != null)
            {
                // Update existing HBL Activity
                var hblLog = new HBLHistoryLog
                {
                    HBLActivityId = hblActivity.Id,
                    CurrentStatus = model.CurrentStatus.Trim(),
                    Comment = model.Comment,
                    EnterBy = userid,
                    StartTime = model.StartTime,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,
                    EnterStartDate = DateTime.UtcNow.AddMinutes(-2),
                    EnterEndDate = DateTime.UtcNow
                };
                _ctx.HBLHistoryLog.Add(hblLog);

                hblActivity.HblId = hblEntry.Id;
                hblActivity.ActivityId = model.Activity;
                hblActivity.EnterBy = userid;
                hblActivity.CurrentStatus = status.Trim();
                hblActivity.Comment = comment;
                hblActivity.StartTime = Convert.ToDateTime(startDate).ToUniversalTime();
                hblActivity.EndTime = DateTime.UtcNow;
                _ctx.HblActivity.Update(hblActivity);

                hblActivity.HblEntry.Hblno = model.Hblno.Trim();
                hblActivity.HblEntry.PLD = model.PLD.Trim();
                hblActivity.HblEntry.HBLType = model.HBLType.Trim();
                hblActivity.HblEntry.IsDap = model.IsDap.Trim().ToLower() == "yes" ? true : false;
                hblActivity.HblEntry.CreatedBy = userid;
                _ctx.HblEntry.Update(hblActivity.HblEntry);
                _ctx.SaveChanges();

                // Check if all HBLs in the file are completed
                if (hblActivityList != null)
                {
                    var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster)
                        .Where(x => x.FileActivityId == model.Activity && x.IsActive)
                        .Select(x => x.HBLActivityId)
                        .FirstOrDefault();
                    var hblStatusCount = hblActivityList.Count(x => x.CurrentStatus != "Completed" && x.ActivityId == HBLActivityMapId);
                    if (hblStatusCount == 0)
                    {
                        var fileActivity = _ctx.FileActivity.Include(x => x.User)
                                            .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                            .Where(x => x.FileId == model.Id && x.ActivityId == hblActivity.ActivityId 
                                                        && x.ActivityMaster.IsActive == true && x.User.IsActive == true 
                                                        && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
                                         
                        if (fileActivity != null)
                        {
                            fileActivity.UserId = userid;
                            fileActivity.CurrentStatus = "Completed";
                            fileActivity.Comment = "All HBLs in this file are completed.";
                            fileActivity.StartTime = Convert.ToDateTime(startDate).ToUniversalTime();
                            fileActivity.EndTime = DateTime.UtcNow;
                            _ctx.FileActivity.Update(fileActivity);
                            _ctx.SaveChanges();
                        }
                    }
                }
            }
            else
            {
                // Create new HBL Activity
                var newHblActivity = new HblActivity
                {
                    HblId = hblEntry.Id,
                    ActivityId = model.Activity,
                    CurrentStatus = model.CurrentStatus.Trim(),
                    Comment = model.Comment,
                    EnterBy = userid,
                    StartTime = DateTime.UtcNow.AddMinutes(-2),
                    EndTime = DateTime.UtcNow,
                    EnterDate = DateTime.UtcNow
                };
                _ctx.HblActivity.Add(newHblActivity);
                _ctx.SaveChanges();
            }

            return Json("Success");
        }

        [HttpPost]
        public IActionResult DeleteActivityHBL(string hblNo, string fileGuidId, string hblId, string activity, string id, string fileNos)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            // Find the HBL Entry
            var hblEntry = _ctx.HblEntry.FirstOrDefault(x => x.Hblno.Trim() == hblNo.Trim());

            if (hblEntry != null)
            {
                // Find the related HBL Activity
                var hblActivities = _ctx.HblActivity.Include(x => x.HblEntry)
                                                     .Include(x => x.User)
                                                     .Include(x => x.ActivityMaster)
                                                     .ThenInclude(x => x.ThreadMaster)
                                                     .Where(x => x.HblId == hblEntry.Id && x.ActivityId == activity)
                                                     .ToList();

                if (hblActivities.Any())
                {
                    foreach (var act in hblActivities)
                    {
                        // Remove from HBL History Log
                        var hblHistoryLogs = _ctx.HBLHistoryLog.Where(x => x.HBLActivityId == act.Id).ToList();
                        if (hblHistoryLogs.Any())
                        {
                            _ctx.HBLHistoryLog.RemoveRange(hblHistoryLogs);
                        }
                    }

                    // Remove HBL Activity
                    _ctx.HblActivity.RemoveRange(hblActivities);
                    _ctx.SaveChanges();

                    // Update or Remove HBL Entry
                    var otherHblActivities = _ctx.HblActivity.Where(x => x.HblId == hblEntry.Id).ToList();
                    if (!otherHblActivities.Any())
                    {
                        // If no other activities related to this HBL Entry, remove the HBL Entry
                        _ctx.HblEntry.Remove(hblEntry);
                        _ctx.SaveChanges();
                    }

                    return Json("Success");
                }
            }

            return Json("Failed");
        }


        [HttpPost]
        public IActionResult FileSubmit(FileActivityDataList model, string status, string comment, string startDate, int? pages, string isEdi, string? fileNo, string? containerNo, string? eta)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            FileActivity fileActivity = _ctx.FileActivity.Include(x => x.FileEntry)
                                        .Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                        .Where(x => x.FileId == model.Id.Trim() && x.ActivityId == model.Activity 
                                                    && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.User)
                                    .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                    .Where(x => x.HblEntry.FileGuidId == model.Id.Trim() && x.ActivityMaster.IsActive == true 
                                                && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

            if (model != null)
            {
                if (fileActivity != null)
                {
                    var HBLActivityMapId = _ctx.ActivityMapping.Include(x => x.FileActivityMaster)
                                            .Where(x => x.FileActivityId == fileActivity.ActivityId && x.IsActive == true)
                                            .Select(x => x.HBLActivityId).FirstOrDefault();
                    if (HBLActivityMapId != null)
                    {

                        var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed" && x.ActivityId == HBLActivityMapId && x.EnterBy == userid).Count();
                        if (hblStatus == 0)
                        {
                            var hbllog = _ctx.FileHistoryLog.Add(new FileHistoryLog
                            {

                                FileActivityId = fileActivity.Id,
                                CurrentStatus = model.CurrentStatus,
                                Comment = model.Comment,
                                UserId = userid,
                                StartTime = model.StartTime,
                                EndTime = model.EndTime,
                                EnterDate = model.EnterDate,
                                EnterStartDate = DateTime.UtcNow.AddMinutes(-2),
                                EnterEndDate = DateTime.UtcNow,
                                Pages = model.Pages,

                            });
                            _ctx.SaveChanges();

                            var file = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User)
                                        .Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                                        .Where(x => x.Id == fileActivity.Id && x.ActivityId == fileActivity.ActivityId 
                                                    && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
                            if (file.ActivityId == model.Activity && file.CurrentStatus != "Completed")
                            {
                                if (file.ActivityId == model.Activity && status != "Completed")
                                {
                                    file.UserId = userid;
                                    file.CurrentStatus = status;
                                    file.Comment = comment;
                                    file.Pages = pages;
                                    file.FileEntry.FileNo = file.FileEntry.FileNo != fileNo ? fileNo : file.FileEntry.FileNo;
                                    file.FileEntry.ContainerNo = file.FileEntry.ContainerNo != containerNo ? containerNo : file.FileEntry.ContainerNo;
                                    file.FileEntry.EtaAtPod = file.FileEntry.EtaAtPod.Value.Date != Convert.ToDateTime(eta).Date ? Convert.ToDateTime(eta).Date : file.FileEntry.EtaAtPod;
                                    file.FileEntry.IsEdi = isEdi;
                                    _ctx.FileActivity.Update(file);
                                    _ctx.FileEntry.Update(file.FileEntry);
                                    _ctx.SaveChanges();
                                }
                                else
                                {
                                    file.UserId = userid;
                                    file.CurrentStatus = status;
                                    file.Comment = comment;
                                    file.StartTime = Convert.ToDateTime(startDate).ToUniversalTime();
                                    file.EndTime = DateTime.Now.ToUniversalTime();
                                    file.Pages = pages;
                                    file.FileEntry.FileNo = file.FileEntry.FileNo != fileNo ? fileNo : file.FileEntry.FileNo;
                                    file.FileEntry.ContainerNo = file.FileEntry.ContainerNo != containerNo ? containerNo : file.FileEntry.ContainerNo;
                                    file.FileEntry.EtaAtPod = file.FileEntry.EtaAtPod.Value.Date != Convert.ToDateTime(eta).Date ? Convert.ToDateTime(eta).Date : file.FileEntry.EtaAtPod;
                                    file.FileEntry.IsEdi = isEdi;
                                    _ctx.FileActivity.Update(file);
                                    _ctx.FileEntry.Update(file.FileEntry);
                                    _ctx.SaveChanges();
                                }

                            }
                            else
                            {
                                file.UserId = userid;
                                file.CurrentStatus = status;
                                file.Comment = comment;
                                file.Pages = pages;
                                file.FileEntry.FileNo = file.FileEntry.FileNo != fileNo ? fileNo : file.FileEntry.FileNo;
                                file.FileEntry.ContainerNo = file.FileEntry.ContainerNo != containerNo ? containerNo : file.FileEntry.ContainerNo;
                                file.FileEntry.EtaAtPod = file.FileEntry.EtaAtPod.Value.Date != Convert.ToDateTime(eta).Date ? Convert.ToDateTime(eta).Date : file.FileEntry.EtaAtPod;
                                file.FileEntry.IsEdi = isEdi;
                                _ctx.FileActivity.Update(file);
                                _ctx.FileEntry.Update(file.FileEntry);
                                _ctx.SaveChanges();
                            }
                        }
                        else
                        {
                            return Json("Please Update HBL in selected file");
                        }
                    }
                    else
                    {
                        return Json("MapActivity");
                    }
                }


                return Json("Success");
            }
            else
            {
                return Json("Failed");

            }
        }
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  B
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        public ActionResult Reports()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Reports(ReportViewModel report)
        {
            DataTable dt = CreateDataTable(report.ReportType);
            DataTable dt1 = CreateDataTable(report.ReportType);

            var startDate = report.start_date;
            var endDate = report.end_date;
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (report.start_date == null || report.end_date == null)
            {
                ViewBag.ErrorMessage = "Please Select Date";
                return View();
            }

            if (report.ReportType == "File")
            {
                var fileactivtydata = GetFileActivityData(report.DateType, startDate, endDate, userid);
                var fileactivtyHistory = GetFileHistoryData(report.DateType, startDate, endDate, userid);

                var fileactivtydataList = fileactivtydata.Select(x => MapFileReportViewModel(x, istTimeZone)).ToList();
                var fileactivtyHistoryList = fileactivtyHistory.Select(x => MapFileHistoryReportViewModel(x, istTimeZone)).ToList();

                FillDataTable(fileactivtydataList, dt);
                FillDataTable(fileactivtyHistoryList, dt1);

                return ExportToExcel(new List<DataTable> { dt, dt1 }, "File Data Report");
            }
            else if (report.ReportType == "HBL")
            {
                var HBLdata = GetHBLActivityData(report.DateType, startDate, endDate, userid);
                var HBLHistory = GetHBLHistoryData(report.DateType, startDate, endDate, userid);

                var HBLdataList = HBLdata.Select(x => MapHBLReportViewModel(x, istTimeZone)).ToList();
                var HBLHistoryList = HBLHistory.Select(x => MapHBLHistoryReportViewModel(x, istTimeZone)).ToList();

                FillDataTable(HBLdataList, dt);
                FillDataTable(HBLHistoryList, dt1);

                return ExportToExcel(new List<DataTable> { dt, dt1 }, "HBL Data Report");
            }

            return View();
        }

        private DataTable CreateDataTable(string reportType)
        {
            DataTable dt = new DataTable();
            if (reportType == "File")
            {
                dt.Columns.AddRange(new DataColumn[]
                {
            new DataColumn("Pod"), new DataColumn("EtaAtPod"), new DataColumn("Received Date"), new DataColumn("ContainerNo"),
            new DataColumn("Pol"), new DataColumn("FileType"), new DataColumn("Hblcount"), new DataColumn("IsEdi"),
            new DataColumn("Activity"), new DataColumn("Current Status"), new DataColumn("Comment"), new DataColumn("UserName"),
            new DataColumn("Pages"), new DataColumn("StartDate"), new DataColumn("EndDate"), new DataColumn("FileNo"),
            new DataColumn("VesselName"), new DataColumn("ShippingLine")
                });
            }
            else if (reportType == "HBL")
            {
                dt.Columns.AddRange(new DataColumn[]
                {
            new DataColumn("Received Date"), new DataColumn("FileNo"), new DataColumn("ContainerNo"), new DataColumn("HBLNo"),
            new DataColumn("IsDap"), new DataColumn("Activity"), new DataColumn("Current Status"), new DataColumn("Comment"),
            new DataColumn("UserName"), new DataColumn("StartDate"), new DataColumn("EndDate")
                });
            }
            return dt;
        }

        private List<FileActivity> GetFileActivityData(string dateType, DateTime startDate, DateTime endDate, string userId)
        {
            IQueryable<FileActivity> query = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.UserId == userId && x.FileEntry.CreatedDate != null && x.FileEntry.CreatedDate.Value.Date >= startDate.Date && x.FileEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.UserId == userId && x.EndTime != null && x.EndTime.Value.Date >= startDate.Date && x.EndTime.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.UserId == userId && x.StartTime != null && x.StartTime.Value.Date >= startDate.Date && x.StartTime.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private List<FileHistoryLog> GetFileHistoryData(string dateType, DateTime startDate, DateTime endDate, string userId)
        {
            IQueryable<FileHistoryLog> query = _ctx.FileHistoryLog.Include(x => x.User).Include(x => x.FileActivity.ActivityMaster).Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.UserId == userId && x.FileActivity.FileEntry.CreatedDate != null && x.FileActivity.FileEntry.CreatedDate.Value.Date >= startDate.Date && x.FileActivity.FileEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.UserId == userId && x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date && x.EnterEndDate.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.UserId == userId && x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date && x.EnterStartDate.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private List<HblActivity> GetHBLActivityData(string dateType, DateTime startDate, DateTime endDate, string userId)
        {
            IQueryable<HblActivity> query = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.EnterBy == userId && x.HblEntry.CreatedDate != null && x.HblEntry.CreatedDate.Value.Date >= startDate.Date && x.HblEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.EnterBy == userId && x.EndTime != null && x.EndTime.Value.Date >= startDate.Date && x.EndTime.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.EnterBy == userId && x.StartTime != null && x.StartTime.Value.Date >= startDate.Date && x.StartTime.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private List<HBLHistoryLog> GetHBLHistoryData(string dateType, DateTime startDate, DateTime endDate, string userId)
        {
            IQueryable<HBLHistoryLog> query = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.EnterBy == userId && x.HblActivity.HblEntry.CreatedDate != null && x.HblActivity.HblEntry.CreatedDate.Value.Date >= startDate.Date && x.HblActivity.HblEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.EnterBy == userId && x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date && x.EnterEndDate.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.EnterBy == userId && x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date && x.EnterStartDate.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private FileReportViewModel MapFileReportViewModel(FileActivity x, TimeZoneInfo istTimeZone)
        {
            return new FileReportViewModel
            {
                POD = x.FileEntry.Pod,
                ETA = x.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                ReceivedDate = x.FileEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                ContainerNo = x.FileEntry.ContainerNo,
                POL = x.FileEntry.Pol,
                FileType = x.FileEntry.FileType,
                HBLCount = x.FileEntry.Hblcount,
                IsEdi = x.FileEntry.IsEdi,
                Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.UserId != null ? x.User.CitrixId : "",
                Pages = x.Pages,
                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.FileEntry.FileNo,
                VesselName = x.FileEntry.VesselName,
                ShippingLine = x.FileEntry.ShippingLine,
            };
        }

        private FileReportViewModel MapFileHistoryReportViewModel(FileHistoryLog x, TimeZoneInfo istTimeZone)
        {
            return new FileReportViewModel
            {
                POD = x.FileActivity.FileEntry.Pod,
                ETA = x.FileActivity.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                ReceivedDate = x.FileActivity.FileEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                POL = x.FileActivity.FileEntry.Pol,
                FileType = x.FileActivity.FileEntry.FileType,
                HBLCount = x.FileActivity.FileEntry.Hblcount,
                IsEdi = x.FileActivity.FileEntry.IsEdi,
                Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                Status = x.FileActivity.CurrentStatus != null ? x.FileActivity.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.UserId != null ? x.User.CitrixId : "",
                Pages = x.FileActivity.Pages,
                StartDate = x.FileActivity.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.FileActivity.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.EndTime.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.FileActivity.FileEntry.FileNo,
                VesselName = x.FileActivity.FileEntry.VesselName,
                ShippingLine = x.FileActivity.FileEntry.ShippingLine,
            };
        }

        private HBLReportViewModel MapHBLReportViewModel(HblActivity x, TimeZoneInfo istTimeZone)
        {
            return new HBLReportViewModel
            {
                ReceivedDate = x.HblEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.HblEntry.FileGuid.FileNo,
                ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                HBLNo = x.HblEntry.Hblno,
                IsDap = x.HblEntry.IsDap,
                Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.User != null ? x.User.CitrixId : "",
                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
            };
        }

        private HBLReportViewModel MapHBLHistoryReportViewModel(HBLHistoryLog x, TimeZoneInfo istTimeZone)
        {
            return new HBLReportViewModel
            {
                ReceivedDate = x.HblActivity.HblEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                HBLNo = x.HblActivity.HblEntry.Hblno,
                IsDap = x.HblActivity.HblEntry.IsDap,
                Activity = x.HblActivity.ActivityId != null ? x.HblActivity.ActivityMaster.Name : "",
                Status = x.HblActivity.CurrentStatus != null ? x.HblActivity.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.User != null ? x.User.CitrixId : "",
                StartDate = x.HblActivity.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.HblActivity.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.EndTime.Value, istTimeZone) : (DateTime?)null,
            };
        }

        private void FillDataTable(IEnumerable<object> data, DataTable dt)
        {
            foreach (var item in data)
            {
                var values = item.GetType().GetProperties().Select(p => p.GetValue(item, null)).ToArray();
                dt.Rows.Add(values);
            }
        }

        private ActionResult ExportToExcel(List<DataTable> dataTables, string fileName)
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                for (int i = 0; i < dataTables.Count; i++)
                {
                    wb.Worksheets.Add(dataTables[i], $"Sheet{i + 1}");
                }
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"{fileName}-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx");
                }
            }
        }


    }
}
