﻿using CAImportWorkflow.Data;
using CAImportWorkflow.Models;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Office2010.Excel;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using Syncfusion.JavaScript.Models;
using Syncfusion.Linq;
using System.Data;
using System.Globalization;
using System.Linq.Dynamic.Core;
using System.Reflection;
using System.Security.Claims;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace CAImportWorkflow.Controllers
{

    public class AdminController : Controller
    {
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IHostingEnvironment hostingEnvironment;
        public AdminController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor, IHostingEnvironment _hostingEnvironment)
        {
            hostingEnvironment = _hostingEnvironment;
            _httpContextAccessor = httpContextAccessor;
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        public IActionResult AdminDashboard()
        {
            ViewData["UserName"] = _ctx.User.Where(x => x.IsActive == true).OrderBy(x => x.CitrixId).ToList();
            ViewData["ThreadName"] = _ctx.ThreadMaster.Where(x => x.IsActive == true).OrderBy(x => x.Name).ToList();
            return View();
        }

        ///Add Location
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertLocation()
        {
            List<LocationMaster> locationMaster = _ctx.LocationMaster.OrderBy(x => x.Name).ToList();
            return View(locationMaster);
        }

        /// Create New Location
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult CreateLocation()
        {
            ViewData["LocationId"] = Guid.NewGuid().ToString();
            return PartialView();
        }

        /// Edit Location
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditLocation(string locationId)
        {
            ViewData["LocationName"] = _ctx.LocationMaster.Where(x => x.Id == locationId).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        public JsonResult CreateLocation(LocationMaster model)
        {
            if (ModelState.IsValid)
            {
                LocationMaster locationMaster = _ctx.LocationMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (locationMaster == null)
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        _ctx.LocationMaster.Add(
                            new LocationMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    LocationMaster locationName = _ctx.LocationMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (locationName == null)
                    {
                        locationMaster.Name = model.Name;
                        _ctx.LocationMaster.Update(locationMaster);
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        /// Activate Location     
        public JsonResult ActivateLocation(string Id)
        {
            string message = "";
            if (Id != null)
            {
                LocationMaster master = _ctx.LocationMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.LocationMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Location Activated!" : master.Name + " Location Deactivated!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        ///Create Activity
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertActivity()
        {
            ViewData["ActivityId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.Where(x => x.IsActive == true).ToList();
            ViewData["ActivityList"] = _ctx.ActivityMaster.Select(x => new ActivityMasterModel 
            { 
                Id = x.Id, 
                Name = x.Name, 
                BasedOn = x.BasedOn, 
                IsActive = x.IsActive, 
                ThreadId = x.ThreadId, 
                ThreadName = x.ThreadMaster.Name, 
                Sequence = x.Sequence 
            }).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return PartialView();
        }

        [HttpPost]
        public JsonResult InsertActivity(ActivityMasterModel model)
        {
            if (ModelState.IsValid)
            {
                ActivityMaster activityMaster = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == model.Id.Trim() && x.ThreadMaster.IsActive == true).FirstOrDefault();

                if (activityMaster == null)
                {
                    ActivityMaster activityName = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Name == model.Name.Trim() && x.ThreadMaster.IsActive == true).FirstOrDefault();
                    if (activityName == null)
                    {
                        _ctx.ActivityMaster.Add(
                            new ActivityMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                BasedOn = model.BasedOn,
                                Sequence = model.Sequence,
                                ThreadId = model.ThreadId,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    activityMaster.Name = model.Name;
                    activityMaster.BasedOn = model.BasedOn;
                    activityMaster.ThreadId = model.ThreadId;
                    activityMaster.Sequence = model.Sequence;
                    _ctx.ActivityMaster.Update(activityMaster);
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        ///Create Activity
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertThread()
        {
            ViewData["ThreadId"] = Guid.NewGuid().ToString();
            ViewData["ThreadList"] = _ctx.ThreadMaster.OrderBy(x => x.Sequence).ToList();
            return PartialView();
        }

        [HttpPost]
        public JsonResult InsertThread(ThreadMaster model)
        {
            if (ModelState.IsValid)
            {
                ThreadMaster threadMaster = _ctx.ThreadMaster.Where(x => x.Id == model.Id.Trim()).FirstOrDefault();

                if (threadMaster == null)
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    if (threadName == null)
                    {
                        _ctx.ThreadMaster.Add(
                            new ThreadMaster
                            {
                                Id = model.Id,
                                Name = model.Name,
                                Sequence = model.Sequence,
                                IsActive = true
                            });
                    }
                    else
                    {
                        return Json("Duplicate");
                    }
                }
                else
                {
                    ThreadMaster threadName = _ctx.ThreadMaster.Where(x => x.Name == model.Name.Trim()).FirstOrDefault();
                    threadMaster.Name = model.Name;
                    threadMaster.Sequence = model.Sequence;
                    _ctx.ThreadMaster.Update(threadMaster);
                }

                _ctx.SaveChanges();
                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        ///Add File
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["Location"] = _ctx.LocationMaster.Where(x => x.IsActive == true).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult InsertFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var act = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var act1 = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => (x.Name.ToUpper() == "DV" && x.BasedOn == "File") || (x.Name.ToUpper() == "DIGIVIEW" && x.BasedOn == "File")).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var act2 = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => (x.Name.ToUpper() == "NOA" && x.BasedOn == "File") || (x.Name.ToUpper() == "NOA/DO" && x.BasedOn == "File")).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var activities = act.Union(act1).Union(act2).Distinct().ToList();
            var present = _ctx.FileEntry.Where(x => x.ContainerNo == model.ContainerNo).FirstOrDefault();
            if (present == null)
            {
                FileEntry file = new FileEntry
                {
                    FileNo = model.FileNo,
                    ContainerNo = model.ContainerNo,
                    IsEdi = model.IsEdi,
                    Pol = model.Pol,
                    Pod = model.Pod,
                    Hblcount = model.Hblcount,
                    ActualHblcount = model.ActualHblcount,
                    EtaAtPod = model.EtaAtPod,
                    Status = null,
                    CreatedDate = DateTime.UtcNow,
                    CreatedBy = userid,
                    FileType = model.FileType,
                    ShippingLine = model.ShippingLine
                };
                _ctx.FileEntry.Add(file);

                foreach (ActivityMaster activity in activities)
                {
                    _ctx.FileActivity.Add(new FileActivity
                    {
                        Id = Guid.NewGuid().ToString(),
                        FileId = file.Id,
                        ActivityId = activity.Id,
                        CurrentStatus = "UnAllocated",
                        Comment = null,
                        UserId = null,
                        EnterDate = DateTime.UtcNow,
                    });
                }
                _ctx.SaveChanges();
            }
            return Json("Success");
        }

        //[HttpPost]
        //public JsonResult GetData(string fileno, string type, string etadate, string container, string status, string thread, string user, string? startDate, string? endDate)
        //{
        //    var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
        //    var draw = Request.Form["draw"].FirstOrDefault();
        //    var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
        //    var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
        //    var searchValue = Request.Form["search[value]"].FirstOrDefault();
        //    int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
        //    int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
        //    _ctx.Database.SetCommandTimeout(300);
        //    DateTime? start = string.IsNullOrEmpty(startDate) ? (DateTime?)null : DateTime.Parse(startDate);
        //    DateTime? end = string.IsNullOrEmpty(endDate) ? (DateTime?)null : DateTime.Parse(endDate);
        //    var query = _ctx.Set<FileEntryViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();
        //    var filteredRecords = query.AsQueryable();
        //    var data = query.AsQueryable();
        //    int hblFilter = filteredRecords.Sum(x => Convert.ToInt32(x.Hblcount));
        //    int hblPendingFilter = filteredRecords.Where(x => x.Status.ToLower() == "pending" || x.Status.ToLower() == "wip").Sum(x => Convert.ToInt32(x.Hblcount));
        //    int hblCompletedFilter = filteredRecords.Where(x => x.Status.ToLower() == "completed" && x.StatusCompleted.HasValue && x.StatusCompleted.Value.Date >= start.Value.Date && x.StatusCompleted.Value.Date <= end.Value.Date).Sum(x => Convert.ToInt32(x.Hblcount));
        //    // Apply filters in a single pass to minimize the number of iterations
        //    if (!string.IsNullOrEmpty(fileno))
        //        query = query.Where(x => x.FileNo == fileno.Trim());

        //    if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
        //        query = query.Where(x => x.FileType == type.Trim());

        //    if (!string.IsNullOrEmpty(etadate))
        //    {
        //        var etaDate = Convert.ToDateTime(etadate).Date;
        //        query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date == etaDate);
        //    }

        //    //if (startDate.HasValue && endDate.HasValue)
        //    //{
        //    //    if (startDate.Value.Date != DateTime.Now.Date || endDate.Value.Date != DateTime.Now.Date)
        //    //    {
        //    //        query = query.Where(x =>
        //    //            (x.CreatedDate.HasValue && x.CreatedDate.Value.Date >= startDate && x.CreatedDate.Value.Date <= endDate) ||
        //    //            (x.StatusCompleted.HasValue && x.StatusCompleted.Value.Date >= startDate && x.StatusCompleted.Value.Date <= endDate));
        //    //    }
        //    //}

        //    if (start.HasValue && end.HasValue && start.Value.Date != DateTime.Now.Date && end.Value.Date != DateTime.Now.Date)
        //    {
        //        //var start = startDate.Value.Date;
        //        //var end = endDate.Value.Date;

        //        query = query.Where(x => (x.CreatedDate.HasValue && x.CreatedDate.Value.Date >= start.Value.Date && x.CreatedDate.Value.Date <= end.Value.Date) ||
        //                                  (x.StatusCompleted.HasValue && x.StatusCompleted.Value.Date >= start.Value.Date && x.StatusCompleted.Value.Date <= end.Value.Date));
        //    }

        //    if (!string.IsNullOrEmpty(container))
        //        query = query.Where(x => x.ContainerNo == container.Trim());

        //    if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
        //        query = query.Where(x => x.AllocatedTo == user.Trim());

        //    if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
        //    {
        //        query = query.Where(x => x.Status == status.Trim());
        //    }
        //    //else if (searchValue == "Completed")
        //    //{
        //    //    query = query.Where(x => x.Status  == "Completed".Trim());
        //    //}
        //    //else
        //    //{
        //    //    query = query.Where(x => x.Status == status.Trim());
        //    //}

        //    if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select Thread--")
        //        query = query.Where(x => x.ThreadName == thread.Trim());

        //    if (!string.IsNullOrEmpty(searchValue) && searchValue != "Received")
        //    {
        //        var now = DateTime.Now.Date;
        //        switch (searchValue)
        //        {
        //            case "eta10":
        //                query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now.AddDays(4) && x.EtaAtPod.Value.Date < now.AddDays(11) && x.Status != "Completed");
        //                break;
        //            case "eta12":
        //                query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(4) && x.Status != "Completed");
        //                break;
        //            case "UnTouched":
        //                query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(5) && x.ManifestCompleted != "Completed");
        //                break;
        //            case "Pending":
        //                query = query.Where(x => x.Status == "Pending");
        //                break;
        //            case "WIP":
        //                query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(3) && x.TsConnectingCompleted != "Completed");
        //                break;
        //            default:
        //                query = query.Where(x => x.Status == searchValue);
        //                break;
        //        }
        //    }

        //    // Sorting
        //    query = !string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection)
        //            ? query = query.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable()
        //            : query.OrderBy(x => x.CreatedDate);

        //    var totalRecords = query.Count();
        //    filteredRecords = query.AsQueryable();

        //    var returnObj = new
        //    {
        //        draw = draw,
        //        recordsTotal = data.Count(),
        //        recordsFiltered = filteredRecords.Count(),
        //        data = filteredRecords.ToList(),
        //        hblCount = hblFilter,
        //        hblPendingCount = hblPendingFilter,
        //        hblCompleted = hblCompletedFilter
        //    };

        //    ViewData["TotalHBL"] = hblFilter;
        //    return Json(returnObj);
        //}

        public async Task<IActionResult> GetData(string fileno, string type, string etadate, string container, string status, string thread, string user, string? startDate, string? endDate)
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "10");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            //var start = string.IsNullOrEmpty(startDate) ? (DateTime?)null : DateTime.ParseExact(startDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            //var end = string.IsNullOrEmpty(endDate) ? (DateTime?)null : DateTime.ParseExact(endDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            DateTime? currentDate = DateTime.Now;
            DateTime? threeMonth = DateTime.Now.AddMonths(-3);
            DateTime? start = !string.IsNullOrEmpty(startDate)
           ? DateTime.ParseExact(startDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
           : (DateTime?)null;

            DateTime? end = !string.IsNullOrEmpty(endDate)
                ? DateTime.ParseExact(endDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
                : (DateTime?)null;
            
            DateTime? startingDate = !string.IsNullOrEmpty(startDate)
           ? DateTime.ParseExact(startDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
           : (DateTime?)null;

            DateTime? endingDate = !string.IsNullOrEmpty(endDate)
                ? DateTime.ParseExact(endDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
                : (DateTime?)null;

            // Convert DateTime to "yyyy-MM-dd" format strings
            string startFormatted = start.HasValue ? start.Value.ToString("yyyy-MM-dd") : null;
            string endFormatted = end.HasValue ? end.Value.ToString("yyyy-MM-dd") : null;
            string currentDateFormatted = currentDate.HasValue ? currentDate.Value.ToString("yyyy-MM-dd") : null;
            string threeMonthFormatted = threeMonth.HasValue ? threeMonth.Value.ToString("yyyy-MM-dd") : null;

            if (start.Value.Date == DateTime.Now.Date && end.Value.Date == DateTime.Now.Date)
            {
                startFormatted = null;
                endFormatted = null;
            }
            else
            {
                startFormatted = startFormatted;
                endFormatted = endFormatted;
            }
           
            var result = await _ctx.Set<FileEntryViewModel>()
                .FromSqlRaw("EXEC GetFilteredData @FileNo, @Type, @EtaDate, @Container, @Status, @Thread, @User, @StartDate, @EndDate",
                    new SqlParameter("@FileNo", (object)fileno ?? DBNull.Value),
                    new SqlParameter("@Type", (object)type ?? DBNull.Value),
                    new SqlParameter("@EtaDate", (object)etadate ?? DBNull.Value),
                    new SqlParameter("@Container", (object)container ?? DBNull.Value),
                    new SqlParameter("@Status", (object)status ?? DBNull.Value),
                    new SqlParameter("@Thread", (object)thread ?? DBNull.Value),
                    new SqlParameter("@User", (object)user ?? DBNull.Value),
                    new SqlParameter("@StartDate", (object)startFormatted ?? DBNull.Value),
                    new SqlParameter("@EndDate", (object)endFormatted ?? DBNull.Value))
                .ToListAsync();

            // Apply sorting and paging
            var query = result.AsQueryable();
            var totalRecords = query.Count();
            if (startingDate.HasValue && endingDate.HasValue && startingDate.Value.Date == DateTime.Now.Date && endingDate.Value.Date == DateTime.Now.Date)
            {
                start = startingDate.HasValue ? startingDate : (DateTime?)null;
                end = endingDate.HasValue ? endingDate : (DateTime?)null;
            }
            int hblFilter = query.Sum(x => Convert.ToInt32(x.Hblcount));
            int hblPendingFilter = query.Where(x => x.Status.ToLower() == "pending" || x.Status.ToLower() == "wip").Sum(x => Convert.ToInt32(x.Hblcount));
            int hblCompletedFilter = query.Where(x => x.Status.ToLower() == "completed" && x.StatusCompleted.HasValue && x.StatusCompleted.Value.Date >= start.Value.Date && x.StatusCompleted.Value.Date <= end.Value.Date).Sum(x => Convert.ToInt32(x.Hblcount));

            if (!string.IsNullOrEmpty(searchValue) && searchValue != "Received")
            {
                var now = DateTime.Now.Date;
                switch (searchValue)
                {
                    case "eta10":
                        query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now.AddDays(4) && x.EtaAtPod.Value.Date < now.AddDays(11) && x.Status != "Completed");
                        break;
                    case "eta12":
                        query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(4) && x.Status != "Completed");
                        break;
                    case "UnTouched":
                        query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(5) && x.ManifestCompleted != "Completed");
                        break;
                    case "Pending":
                        query = query.Where(x => x.Status == "Pending");
                        break;
                    case "WIP":
                        query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < now.AddDays(3) && x.TsConnectingCompleted != "Completed");
                        break;
                    default:
                        query = query.Where(x => x.Status == searchValue);
                        break;
                }
            }
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                query = query.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }
            else
            {
                query = query.OrderBy(x => x.CreatedDate);
            }

            var filteredRecords = query/*.Skip(skip).Take(pageSize)*/.ToList();

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecords,
                recordsFiltered = filteredRecords.Count,
                data = filteredRecords,
                hblCount = hblFilter,
                hblPendingCount = hblPendingFilter,
                hblCompleted = hblCompletedFilter
            };

            ViewData["TotalHBL"] = returnObj.hblCount;
            return Json(returnObj);
        }


        //public JsonResult GetDashboardValue(string fileno, string type, string etadate, string container, string status, string thread, string user, string? startDate, string? endDate)
        //{
        //    _ctx.Database.SetCommandTimeout(300);
        //    var query = _ctx.Set<FileEntryViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardCount").AsQueryable();

        //    // Apply filters
        //    if (!string.IsNullOrEmpty(fileno))
        //        query = query.Where(x => x.FileNo == fileno.Trim());

        //    if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
        //        query = query.Where(x => x.FileType == type.Trim());

        //    if (!string.IsNullOrEmpty(etadate))
        //    {
        //        var etaDate = Convert.ToDateTime(etadate).Date;
        //        query = query.Where(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date == etaDate);
        //    }

        //    //if (startDate != null && endDate != null && startDate.Value.Date != DateTime.Now.Date && endDate.Value.Date != DateTime.Now.Date)
        //    //{
        //    //    var start = Convert.ToDateTime(startDate).Date;
        //    //    var end = Convert.ToDateTime(endDate).Date;
        //    //    query = query.Where(x => (x.CreatedDate.HasValue && x.CreatedDate.Value.Date >= start && x.CreatedDate.Value.Date <= end) ||
        //    //                              (x.StatusCompleted.HasValue && x.StatusCompleted.Value.Date >= start && x.StatusCompleted.Value.Date <= end));
        //    //}

        //    DateTime? start = string.IsNullOrEmpty(startDate) ? (DateTime?)null : DateTime.Parse(startDate);
        //    DateTime? end = string.IsNullOrEmpty(endDate) ? (DateTime?)null : DateTime.Parse(endDate);

        //    if (start.HasValue && end.HasValue && start.Value.Date != DateTime.Now.Date && end.Value.Date != DateTime.Now.Date)
        //    {
        //        //var start = startDate.Value.Date;
        //        //var end = endDate.Value.Date;

        //        query = query.Where(x => (x.CreatedDate.HasValue && x.CreatedDate.Value.Date >= start.Value.Date && x.CreatedDate.Value.Date <= end.Value.Date) ||
        //                                  (x.StatusCompleted.HasValue && x.StatusCompleted.Value.Date >= start.Value.Date && x.StatusCompleted.Value.Date <= end.Value.Date));
        //    }

        //    if (!string.IsNullOrEmpty(container))
        //        query = query.Where(x => x.ContainerNo == container.Trim());

        //    if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
        //        query = query.Where(x => x.AllocatedTo == user.Trim());

        //    if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
        //        query = query.Where(x => x.Status == status.Trim());

        //    if (!string.IsNullOrEmpty(thread) && thread != "none" && thread != "--Select Thread--")
        //        query = query.Where(x => x.ThreadName == thread.Trim());

        //    DateTime now = DateTime.Now.Date;
        //    DateTime nowPlus3Days = now.AddDays(3);
        //    DateTime nowPlus5Days = now.AddDays(5);
        //    DateTime nowPlus4Days = now.AddDays(4);
        //    DateTime nowPlus11Days = now.AddDays(11);
        //    var queryList = query.ToList(); // Materialize the query once to avoid multiple database calls

        //    AdminDashboardCountModel model = new AdminDashboardCountModel
        //    {
        //        Received = queryList.Count(),
        //        WIP = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < nowPlus3Days && x.TsConnectingCompleted != "Completed"),
        //        Pending = queryList.Count(x => x.Status.ToLower() == "pending"),
        //        Completed = queryList.Count(x => x.Status == "Completed"),
        //        Query = queryList.Count(x => x.Status == "Query"),
        //        UnTouched = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < nowPlus5Days && x.ManifestCompleted != "Completed"),
        //        eta10 = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= nowPlus4Days && x.EtaAtPod.Value.Date < nowPlus11Days && x.Status != "Completed"),
        //        eta12 = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < nowPlus4Days && x.Status != "Completed"),
        //    };

        //    return Json(model);
        //}

        public async Task<JsonResult> GetDashboardValue(string fileno, string type, string etadate, string container, string status, string thread, string user, string? startDate, string? endDate)
        {
            _ctx.Database.SetCommandTimeout(300);
            DateTime? currentDate = DateTime.Now;
            DateTime? threeMonth = DateTime.Now.AddMonths(-3);
            DateTime? start = !string.IsNullOrEmpty(startDate)
           ? DateTime.ParseExact(startDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
           : (DateTime?)null;

            DateTime? end = !string.IsNullOrEmpty(endDate)
                ? DateTime.ParseExact(endDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
                : (DateTime?)null;

            DateTime? startingDate = !string.IsNullOrEmpty(startDate)
           ? DateTime.ParseExact(startDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
           : (DateTime?)null;

            DateTime? endingDate = !string.IsNullOrEmpty(endDate)
                ? DateTime.ParseExact(endDate, "MMM/dd/yyyy", CultureInfo.InvariantCulture)
                : (DateTime?)null;

            // Convert DateTime to "yyyy-MM-dd" format strings
            string startFormatted = start.HasValue ? start.Value.ToString("yyyy-MM-dd") : null;
            string endFormatted = end.HasValue ? end.Value.ToString("yyyy-MM-dd") : null;
            string currentDateFormatted = currentDate.HasValue ? currentDate.Value.ToString("yyyy-MM-dd") : null;
            string threeMonthFormatted = threeMonth.HasValue ? threeMonth.Value.ToString("yyyy-MM-dd") : null;

            if (start.Value.Date == DateTime.Now.Date && end.Value.Date == DateTime.Now.Date)
            {
                startFormatted = null;
                endFormatted = null;
            }
            else
            {
                startFormatted = startFormatted;
                endFormatted = endFormatted;
            }

            var result = await _ctx.Set<FileEntryViewModel>()
                .FromSqlRaw("EXEC GetFilteredData @FileNo, @Type, @EtaDate, @Container, @Status, @Thread, @User, @StartDate, @EndDate",
                    new SqlParameter("@FileNo", (object)fileno ?? DBNull.Value),
                    new SqlParameter("@Type", (object)type ?? DBNull.Value),
                    new SqlParameter("@EtaDate", (object)etadate ?? DBNull.Value),
                    new SqlParameter("@Container", (object)container ?? DBNull.Value),
                    new SqlParameter("@Status", (object)status ?? DBNull.Value),
                    new SqlParameter("@Thread", (object)thread ?? DBNull.Value),
                    new SqlParameter("@User", (object)user ?? DBNull.Value),
                    new SqlParameter("@StartDate", (object)startFormatted ?? DBNull.Value),
                    new SqlParameter("@EndDate", (object)endFormatted ?? DBNull.Value))
                .ToListAsync();

            // Apply sorting and paging
            var query = result.AsQueryable();
            var totalRecords = query.Count();
            if (startingDate.HasValue && endingDate.HasValue && startingDate.Value.Date == DateTime.Now.Date && endingDate.Value.Date == DateTime.Now.Date)
            {
                start = startingDate.HasValue ? startingDate : (DateTime?)null;
                end = endingDate.HasValue ? endingDate : (DateTime?)null;
            }
           
            var filteredRecords = query/*.Skip(skip).Take(pageSize)*/.ToList();

            DateTime now = DateTime.Now.Date;
            DateTime nowPlus3Days = now.AddDays(3);
            DateTime nowPlus5Days = now.AddDays(5);
            DateTime nowPlus4Days = now.AddDays(4);
            DateTime nowPlus11Days = now.AddDays(11);
            var queryList = filteredRecords.ToList(); // Materialize the query once to avoid multiple database calls

            AdminDashboardCountModel model = new AdminDashboardCountModel
            {
                Received = queryList.Count(),
                WIP = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < nowPlus3Days && x.TsConnectingCompleted != "Completed"),
                Pending = queryList.Count(x => x.Status.ToLower() == "pending"),
                Completed = queryList.Count(x => x.Status == "Completed"),
                Query = queryList.Count(x => x.Status == "Query"),
                UnTouched = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < nowPlus5Days && x.ManifestCompleted != "Completed"),
                eta10 = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= nowPlus4Days && x.EtaAtPod.Value.Date < nowPlus11Days && x.Status != "Completed"),
                eta12 = queryList.Count(x => x.EtaAtPod.HasValue && x.EtaAtPod.Value.Date >= now && x.EtaAtPod.Value.Date < nowPlus4Days && x.Status != "Completed"),
            };

            return Json(model);
        }

        [HttpGet]
        public IActionResult GetHblData(string fileId, string hblId)
        {
            TimeZoneInfo utcZone = TimeZoneInfo.Utc;
            TimeZoneInfo istZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            var hblEntry = _ctx.HblEntry.Where(x => x.FileGuidId == fileId).Select(x => new HBLDataList
            {
                Id = x.Id,
                Hblno = x.Hblno == null ? "" : x.Hblno,
                HBLType = x.HBLType == null ? "" : x.HBLType,
                PLD = x.PLD == null ? "" : x.PLD,
                FileGuidId = x.FileGuidId,
                IsDap = x.IsDap,
                CreatedDate = x.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, istZone) : (DateTime?)null,
                CreatedBy = x.User.UserName == null ? "" : x.User.UserName,
            }).ToList();

            var fileEntryData = _ctx.FileActivity
                .Include(x => x.FileEntry)
                .Where(x => x.FileId == fileId)
                .Select(x => new FileDataList
                {
                    ActivityId = x.ActivityMaster.Name,
                    Comment = x.Comment ?? "",
                    CurrentStatus = x.CurrentStatus,
                    EndTime = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istZone) : (DateTime?)null,
                    StartTime = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istZone) : (DateTime?)null,
                    EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, istZone) : (DateTime?)null,
                    FileNo = x.FileEntry.FileNo ?? "",
                    Id = x.FileId,
                    UserId = x.User.UserName ?? "",
                }).ToList();

            return Json(new { fileEntryData, hblEntry });
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        public ActionResult Report()
        {
            return View();
        }

        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult ActivityMapping()
        {
            ViewData["HBLStatusList"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            var result = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                            .Where(x => x.BasedOn == "File" && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name)
                            .Select(x => new ActivityMapModel
                            {
                                FileActivityId = x.Id,
                                FileActivityName = x.Name,
                                ThreadName = x.ThreadMaster.Name,
                                HBLMappedActivityList = _ctx.ActivityMapping.Include(y => y.HBLActivityMaster).Where(y => y.FileActivityMaster.Id == x.Id).OrderBy(y => y.HBLActivityMaster.Name).Select(y => y.HBLActivityMaster.Id).ToList()
                            }).ToList();

            return View(result);
        }

        [HttpPost]
        public IActionResult ActivityMapping(ActivityMapModel activitymap)
        {
            var assignedHBLStatus = _ctx.ActivityMapping.Where(x => x.FileActivityMaster.Id == activitymap.FileActivityId).ToList();
            try
            {
                _ctx.RemoveRange(assignedHBLStatus);

                if (activitymap.HBLMappedActivityList != null)
                    foreach (var multi in activitymap.HBLMappedActivityList)
                    {
                        _ctx.ActivityMapping.Add(new ActivityMapping
                        {
                            Id = Guid.NewGuid().ToString(),
                            FileActivityId = activitymap.FileActivityId,
                            HBLActivityId = multi.ToString(),
                            IsActive = true
                        });
                    }

                _ctx.SaveChanges();
                return Json("success");
            }
            catch (Exception ex)
            {
                return Json("failed");
            }
        }

        public JsonResult MultiAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == multilist.eId && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            if(fileActivity.CurrentStatus != "Completed")
                            {
                                fileActivity.CurrentStatus = "WIP";
                                fileActivity.UserId = model.uname;
                                _ctx.FileActivity.Update(fileActivity);
                            }
                            else
                            {
                                return Json("File processing activity already completed for container no :" + fileActivity.FileEntry.ContainerNo);
                            }
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }
        }

        public JsonResult MultiDeAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    List<FileActivity> fileActivitiesList = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.FileId == multilist.eId && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

                    foreach (FileActivity fileActivity in fileActivitiesList)
                    {
                        if (fileActivity != null)
                        {
                            fileActivity.UserId = model.uname;
                            _ctx.FileActivity.Update(fileActivity);
                        }
                    }
                }
                _ctx.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }
        }

        public JsonResult FileDetails(FileDetailsViewModel model)
        {
            var result = _ctx.FileEntry.Where(x => x.Id == model.Filedetails.Id).FirstOrDefault();
            return Json(model);
        }

        [HttpPost]
        public IActionResult PreAlertDataReport(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();
            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());
            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());
            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));
            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());
            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());
            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));
                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }
                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                data = data.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            var fileEntryData = new List<FileEntryData>();
            var fileEntryViewModels = data
                    .Include(x => x.FileActivity)
                    .ThenInclude(fa => fa.ActivityMaster)
                    .ThenInclude(am => am.ThreadMaster)
                    .Select(x => new
                    {
                        CreatedDate = x.CreatedDate.HasValue
                            ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, indiaTimeZone)
                            : (DateTime?)null,
                        FileNo = x.FileNo,
                        ContainerNo = x.ContainerNo,
                        IsEdi = x.IsEdi,
                        Pol = x.Pol,
                        Pod = _ctx.LocationMaster
                            .Where(y => y.Id == x.Pod && y.IsActive)
                            .Select(y => y.Name)
                            .FirstOrDefault(),
                        FileType = x.FileType,
                        Hblcount = x.Hblcount,
                        EtaAtPod = x.EtaAtPod.HasValue
                            ? TimeZoneInfo.ConvertTimeFromUtc(x.EtaAtPod.Value, indiaTimeZone)
                            : (DateTime?)null,
                        VesselName = x.VesselName,
                        ShippingLine = x.ShippingLine,
                        ThreadName = x.FileActivity
                            .Where(fa => fa.FileId == x.Id && fa.ActivityMaster.IsActive == true && fa.User.IsActive == true && fa.ActivityMaster.ThreadMaster.IsActive == true)
                            .OrderByDescending(fa => fa.EnterDate)
                            .Select(fa => fa.ActivityMaster.ThreadMaster.Name)
                            .FirstOrDefault(),
                        Status = x.FileActivity
                            .Where(fa => fa.FileId == x.Id && fa.ActivityMaster.IsActive == true && fa.User.IsActive == true && fa.ActivityMaster.ThreadMaster.IsActive == true)
                            .OrderByDescending(fa => fa.EnterDate)
                            .Select(fa => fa.CurrentStatus)
                            .FirstOrDefault(),
                        AllocatedTo = x.FileActivity
                            .Where(fa => fa.FileId == x.Id && fa.ActivityMaster.IsActive == true && fa.User.IsActive == true && fa.ActivityMaster.ThreadMaster.IsActive == true)
                            .OrderByDescending(fa => fa.EnterDate)
                            .Select(fa => fa.User != null ? fa.User.UserName : null)
                            .FirstOrDefault(),
                    }).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            dt.Columns.Add("ThreadName");
            dt.Columns.Add("Status");
            dt.Columns.Add("AllocatedTo");

            foreach (var file in fileEntryViewModels)
            {

                DataRow tr = dt.NewRow();
                tr[0] = file.CreatedDate;
                tr[1] = file.FileNo;
                tr[2] = file.ContainerNo;
                tr[3] = file.IsEdi;
                tr[4] = file.Pol;
                tr[5] = file.Pod;
                tr[6] = file.FileType;
                tr[7] = file.Hblcount;
                tr[8] = file.EtaAtPod;
                tr[9] = file.VesselName;
                tr[10] = file.ShippingLine;
                tr[11] = file.ThreadName;
                tr[12] = file.Status;
                tr[13] = file.AllocatedTo;
                dt.Rows.Add(tr);

            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert Report";
                var wsFileData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"PreAlertReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster)
                .Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true)
                .OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();

            IQueryable<FileEntry> data = _ctx.Set<FileEntry>().AsQueryable();
            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileNo == fileno.Trim());
            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileType == type.Trim());
            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.EtaAtPod == Convert.ToDateTime(etadate));
            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.ContainerNo == container.Trim());
            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.Status == status.Trim());
            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod).AddDays(-10) <= DateTime.Now && (x.Status != "Completed"));
                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.EtaAtPod != null && Convert.ToDateTime(x.EtaAtPod)
                    .AddDays(-10) > DateTime.Now && Convert.ToDateTime(x.EtaAtPod).AddDays(-12) <= DateTime.Now && x.Status != "Completed");
                }
                else
                {
                    data = data.Where(x => x.Status == searchValue);
                }
            }

            var fileEntryData = new List<FileEntryData>();
            var indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            var fileEntryViewModels = data
                .Include(x => x.FileActivity)
                    .ThenInclude(x => x.ActivityMaster)
                    .ThenInclude(x => x.ThreadMaster)
                .Select(x => new
                {
                    CreatedDate = x.CreatedDate.HasValue
                        ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, indiaTimeZone)
                        : (DateTime?)null,
                    FileNo = x.FileNo,
                    ContainerNo = x.ContainerNo,
                    IsEdi = x.IsEdi,
                    Pol = x.Pol,
                    Pod = _ctx.LocationMaster
                        .Where(y => y.Id == x.Pod && y.IsActive)
                        .Select(y => y.Name)
                        .FirstOrDefault(),
                    FileType = x.FileType,
                    Hblcount = x.Hblcount,
                    EtaAtPod = x.EtaAtPod.HasValue
                        ? TimeZoneInfo.ConvertTimeFromUtc(x.EtaAtPod.Value, indiaTimeZone)
                        : (DateTime?)null,
                    VesselName = x.VesselName,
                    ShippingLine = x.ShippingLine,
                }).ToList();

            var fileActivityList = _ctx.FileEntry.Include(x => x.User).Include(x => x.FileActivity).ThenInclude(x => x.ActivityMaster)
                    .ThenInclude(x => x.ThreadMaster).ToList();

            foreach (var file in fileActivity.OrderBy(x => x.Sequence).ThenBy(x => x.Name))
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        FileId = item.FileNo,
                        Activity = _ctx.ActivityMaster.Where(x => x.Id == file.Id && x.BasedOn == "File" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        Date = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")) : (DateTime?)null).FirstOrDefault(),
                        Status = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.User == null ? null : x.User.UserName).FirstOrDefault(),
                        Comment = item.FileActivity.Where(x => x.ActivityId == file.Id && x.ActivityMaster.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.Comment).FirstOrDefault()
                    });
                }
            }

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("IsEdi");
            dt.Columns.Add("Pol");
            dt.Columns.Add("Pod");
            dt.Columns.Add("FileType");
            dt.Columns.Add("Hblcount");
            dt.Columns.Add("EtaAtPod");
            dt.Columns.Add("VesselName");
            dt.Columns.Add("ShippingLine");
            foreach (var item in _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" 
                        && x.ThreadMaster.IsActive == true).OrderBy(x => x.ThreadMaster.Sequence)
            )
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }
            
            foreach (var file in fileEntryViewModels)
            {
                // Create a new DataRow for each file
                DataRow tr = dt.NewRow();
                tr[0] = file.CreatedDate;
                tr[1] = file.FileNo;
                tr[2] = file.ContainerNo;
                tr[3] = file.IsEdi;
                tr[4] = file.Pol;
                tr[5] = file.Pod;
                tr[6] = file.FileType;
                tr[7] = file.Hblcount;
                tr[8] = file.EtaAtPod;
                tr[9] = file.VesselName;
                tr[10] = file.ShippingLine;

                foreach (var item in fileActivity.OrderBy(x => x.Sequence).ThenBy(x => x.Name))
                {
                    foreach (var dr in fileEntryData.Where(x => x.Activity == item.Name && x.FileId == file.FileNo))
                    {
                        // Add activity data to the DataRow
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                    }
                }

                // Add the DataRow to the DataTable
                dt.Rows.Add(tr);
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert File Log";
                var wsFileData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"FileActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpPost]
        public IActionResult PreAlertHBLDataDownload(string fileno, string type, string etadate, string container, string status, string thread, string user)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            int totalRecord = 0;
            int filterRecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var HBLActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true 
                                && x.ThreadMaster.IsActive == true).OrderBy(x => x.BasedOn).ThenBy(x => x.Name).ToList();
            IQueryable<HblEntry> data = _ctx.Set<HblEntry>().AsQueryable();
            totalRecord = data.Count();

            if (!string.IsNullOrEmpty(fileno))
            {
                data = data.Where(x => x.FileGuid.FileNo == fileno.Trim());
            }
            if (!string.IsNullOrEmpty(type) && type != "all" && type != "--select--")
            {
                data = data.Where(x => x.FileGuid.FileType == type.Trim());
            }
            if (!string.IsNullOrEmpty(etadate))
            {
                data = data.Where(x => x.FileGuid.EtaAtPod == Convert.ToDateTime(etadate));
            }

            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.FileGuid.ContainerNo == container.Trim());
            }

            if (!string.IsNullOrEmpty(user) && user != "none" && user != "--select--")
            {
                data = data.Where(x => x.CreatedBy == user.Trim());
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
            {
                data = data.Where(x => x.FileGuid.Status == status.Trim());
            }

            if (searchValue == "WIP" || searchValue == "Completed" || searchValue == "Pending" || searchValue == "Query" ||
                        searchValue == "Received" || searchValue == "UnAllocated" || searchValue == "eta10" || searchValue == "eta12")
            {
                if (searchValue == "eta10")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod.Value.Date).AddDays(-10) <= DateTime.Now.Date && (x.FileGuid.Status != "Completed"));
                }
                else if (searchValue == "eta12")
                {
                    data = data.Where(x => x.FileGuid.EtaAtPod != null && Convert.ToDateTime(x.FileGuid.EtaAtPod.Value.Date).AddDays(-10) > DateTime.Now.Date && Convert.ToDateTime(x.FileGuid.EtaAtPod.Value.Date).AddDays(-12) <= DateTime.Now.Date && x.FileGuid.Status != "Completed");
                }
                else
                {
                    data = data.Where(x => x.FileGuid.Status == searchValue);
                }
            }
            var fileEntryData = new List<FileEntryData>();
            var HBLEntryViewModels = data
                    .Include(x => x.HblActivity)
                    .ThenInclude(x => x.ActivityMaster.ThreadMaster)
                    .Select(x => new
                    {
                        FileNo = x.FileGuid.FileNo,
                        ContainerNo = x.FileGuid.ContainerNo,
                        Hblno = x.Hblno,
                        HBLType = x.HBLType,
                        IsDap = x.IsDap == true ? "Yes" : "No",
                        CreatedBy = x.CreatedBy,
                        CreatedDate = x.CreatedDate,
                    })  .ToList();

            // Get the timezone information
            var indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");

            // Perform timezone conversion after fetching data
            var HBLEntryViewModelsWithTimeZone = HBLEntryViewModels.Select(x => new
            {
                x.FileNo,
                x.ContainerNo,
                x.Hblno,
                x.HBLType,
                x.IsDap,
                x.CreatedBy,
                CreatedDate = x.CreatedDate.HasValue
                    ? TimeZoneInfo.ConvertTimeFromUtc(x.CreatedDate.Value, indiaTimeZone)
                    : (DateTime?)null,
            }).ToList();
            var fileActivityList = _ctx.HblEntry.Include(x => x.User).Include(x => x.HblActivity).ThenInclude(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.FileGuid).ToList();
            foreach (var hbl in HBLActivity)
            {
                foreach (var item in fileActivityList)
                {
                    fileEntryData.Add(new FileEntryData
                    {
                        FileId = item.FileGuid.FileNo,
                        HBLId = item.Hblno,
                        Activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.Id == hbl.Id && x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true).Select(x => x.Name).FirstOrDefault(),
                        Date = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")) : (DateTime?)null).FirstOrDefault(),
                        Status = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.CurrentStatus).FirstOrDefault(),
                        UserName = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.User == null ? null : x.User.UserName).FirstOrDefault(),
                        Comment = item.HblActivity.Where(x => x.ActivityId == hbl.Id && x.HblEntry.Hblno == item.Hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.Comment).FirstOrDefault()
                    });
                }
            }

            DataTable dt = new DataTable();
            dt.Columns.Add("Received Date");
            dt.Columns.Add("FileNo");
            dt.Columns.Add("ContainerNo");
            dt.Columns.Add("HBL No");
            dt.Columns.Add("HBL Type");
            dt.Columns.Add("IsDap");
            dt.Columns.Add("CreatedBy");

            foreach (var item in _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "HBL" && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.ThreadMaster.Sequence))
            {
                dt.Columns.Add(item.Name + "_" + "Status");
                dt.Columns.Add(item.Name + "_" + "Date");
                dt.Columns.Add(item.Name + "_" + "UserName");
                dt.Columns.Add(item.Name + "_" + "Comment");
            }

            foreach (var hbl in HBLEntryViewModels)
            {
                DataRow tr = dt.NewRow();
                tr[0] = hbl.CreatedDate;
                tr[1] = hbl.FileNo;
                tr[2] = hbl.ContainerNo;
                tr[3] = hbl.Hblno;
                tr[4] = hbl.HBLType;
                tr[5] = hbl.IsDap;
                tr[6] = hbl.CreatedBy;

                foreach (var item in HBLActivity)
                {
                    var dr = fileEntryData.FirstOrDefault(x => x.Activity == item.Name && x.FileId == hbl.FileNo && x.HBLId == hbl.Hblno);

                    if (dr != null)
                    {
                        tr[item.Name + "_" + "Status"] = dr.Status;
                        tr[item.Name + "_" + "Date"] = dr.Date;
                        tr[item.Name + "_" + "UserName"] = dr.UserName;
                        tr[item.Name + "_" + "Comment"] = dr.Comment;
                    }
                }

                dt.Rows.Add(tr);
            }

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Pre-Alert HBL Log";
                var wsFileData = wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"HBLActivityStatusReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }
        }

        [HttpGet]
        public IActionResult UserActivityStatus([FromQuery(Name = "ThreadName")] string threadName, DateTime? StartDate, DateTime? EndDate)
        {
            return View();
        }

        [HttpPost]
        public IActionResult UserActivityStatusList(DateTime? StartDate, DateTime? EndDate)
        {
            if (StartDate.HasValue && EndDate.HasValue && StartDate.Value.Date == DateTime.Now.Date && EndDate.Value.Date == DateTime.Now.Date)
            {
                StartDate = null;
                EndDate = null;
            }

            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            var searchClick = Request.Form["columns[0][search][value]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();

            // Fetch active file activities and users
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true 
                                && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true).ToList();
            // Fetch file activities within date range
            var fileActivityListQuery = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster)
                                        .ThenInclude(x => x.ThreadMaster).Where(x => x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true);

            if (StartDate.HasValue && EndDate.HasValue)
            {
                fileActivityListQuery = fileActivityListQuery.Where(x => x.EnterDate.Value.Date >= StartDate.Value.Date && x.EnterDate.Value.Date <= EndDate.Value.Date);
            }

            var fileActivityList = fileActivityListQuery.ToList();

            // Prepare result
            var userActivityStatus = new UserActivityStatusViewModel();

            foreach (var user in userList)
            {
                var getFileActivityStatus = fileActivity.Select(item => new FileActivityStatusList
                {
                    Activity = item.Name,
                    ActivityType = item.BasedOn,
                    WIP = fileActivityList.Count(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id && x.UserId == user.Id),
                    Completed = fileActivityList.Count(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id && x.UserId == user.Id),
                    Pending = fileActivityList.Count(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id && x.UserId == user.Id),
                    Query = fileActivityList.Count(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id && x.UserId == user.Id),
                    CompletedWithQuery = fileActivityList.Count(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id && x.UserId == user.Id),
                    Total = fileActivityList.Count(x => x.ActivityId == item.Id && x.UserId == user.Id)
                }).ToList();

                var userStatus = new UserStatusList
                {
                    UserId = user.UserName,
                    WIP = fileActivityList.Count(x => x.CurrentStatus == "WIP" && x.UserId == user.Id),
                    Completed = fileActivityList.Count(x => x.CurrentStatus == "Completed" && x.UserId == user.Id),
                    Pending = fileActivityList.Count(x => x.CurrentStatus == "Pending" && x.UserId == user.Id),
                    Query = fileActivityList.Count(x => x.CurrentStatus == "Query" && x.UserId == user.Id),
                    CompletedWithQuery = fileActivityList.Count(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id),
                    Total = fileActivityList.Count(x => x.UserId == user.Id),
                    GetFileActivityStatus = getFileActivityStatus
                };

                userActivityStatus.GetUserStatusList.Add(userStatus);
            }

            var totalrecords = userActivityStatus.GetUserStatusList.Count();

            // Apply sorting
            var sortedData = userActivityStatus.GetUserStatusList.AsQueryable();
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                if (sortColumn == "userName") sortColumn = "UserId"; // Adjust column name for sorting if needed
                sortedData = sortedData.OrderBy($"{sortColumn} {sortColumnDirection}");
            }

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalrecords,
                recordsFiltered = sortedData.Count(),
                data = sortedData.Skip(skip).Take(pageSize).ToList(), // Pagination
                skip = skip,
                pageSize = pageSize
            };

            return Json(returnObj);
        }

        [HttpPost]
        public IActionResult UserDataDownload(DateTime? StartDate, DateTime? EndDate)
        {
            var userId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var isToday = StartDate.HasValue && EndDate.HasValue && StartDate.Value.Date == DateTime.Now.Date && EndDate.Value.Date == DateTime.Now.Date;
            var fileActivity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive && x.ThreadMaster.IsActive).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var userList = _ctx.User.Where(x => x.IsActive == true).ToList();
            var fileActivityList = isToday ? Enumerable.Empty<FileActivity>() : _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster)
                .Where(x => x.EnterDate.HasValue && x.EnterDate.Value.Date >= (StartDate ?? DateTime.MinValue).Date && x.EnterDate.Value.Date <= (EndDate ?? DateTime.MaxValue).Date
                    && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();

            var getFileActivityStatus = fileActivity.ToDictionary(item => item.Id, item => new FileActivityStatusList
            {
                Activity = item.Name,
                ActivityType = item.BasedOn,
                WIP = fileActivityList.Count(x => x.CurrentStatus == "WIP" && x.ActivityId == item.Id),
                Completed = fileActivityList.Count(x => x.CurrentStatus == "Completed" && x.ActivityId == item.Id),
                Pending = fileActivityList.Count(x => x.CurrentStatus == "Pending" && x.ActivityId == item.Id),
                Query = fileActivityList.Count(x => x.CurrentStatus == "Query" && x.ActivityId == item.Id),
                CompletedWithQuery = fileActivityList.Count(x => x.CurrentStatus == "Completed With Query" && x.ActivityId == item.Id),
                Total = fileActivityList.Count(x => x.ActivityId == item.Id),
            });

            var userActivityStatusList = userList.Select(user => new UserStatusList
            {
                UserId = user.UserName,
                WIP = fileActivityList.Count(x => x.CurrentStatus == "WIP" && x.UserId == user.Id),
                Completed = fileActivityList.Count(x => x.CurrentStatus == "Completed" && x.UserId == user.Id),
                Pending = fileActivityList.Count(x => x.CurrentStatus == "Pending" && x.UserId == user.Id),
                Query = fileActivityList.Count(x => x.CurrentStatus == "Query" && x.UserId == user.Id),
                CompletedWithQuery = fileActivityList.Count(x => x.CurrentStatus == "Completed With Query" && x.UserId == user.Id),
                Total = fileActivityList.Count(x => x.UserId == user.Id),
                GetFileActivityStatus = getFileActivityStatus.Values.ToList(),
                GetHBLActivityStatus = new List<HBLActivityStatusList>() // Assuming similar logic for HBLActivityStatus
            }).ToList();

            var fileStatus = userActivityStatusList.Select(x => new UserStatusList
            {
                UserId = x.UserId,
                Total = x.Total,
                WIP = x.WIP,
                Query = x.Query,
                Pending = x.Pending,
                Completed = x.Completed,
                CompletedWithQuery = x.CompletedWithQuery,
                GetFileActivityStatus = x.GetFileActivityStatus
            }).ToList();

            var dt = new DataTable();
            dt.Columns.AddRange(new[]
            {
                new DataColumn("Username"),
                new DataColumn("Activity"),
                new DataColumn("ActivityType"),
                new DataColumn("Total"),
                new DataColumn("Completed"),
                new DataColumn("CompletedWithQuery"),
                new DataColumn("Pending"),
                new DataColumn("Query"),
                new DataColumn("WIP")
            });

            foreach (var dr in fileStatus)
            {
                foreach (var file in dr.GetFileActivityStatus)
                {
                    dt.Rows.Add(dr.UserId, file.Activity, file.ActivityType, file.Total, file.Completed, file.CompletedWithQuery, file.Pending, file.Query, file.WIP);
                }
            }

            using (var wb = new XLWorkbook())
            {
                dt.TableName = "User Activity Status";
                var wsData = wb.Worksheets.Add(dt);
                using (var stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    var excelName = $"UserActivityStatus-{DateTime.UtcNow:ddMMyyyy HHmmss}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelName);
                }
            }
        }

        [HttpGet]
        public IActionResult GetActivityFileData()
        {
            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetActivityFileData(string activity, string activityType, string status)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault() ?? "fileNo";
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault() ?? "asc";
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            IQueryable<FileActivityDataList> query;

            if (activityType == "HBL")
            {
                query = _ctx.HblActivity.Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.HblEntry)
                    .ThenInclude(x => x.FileGuid).ThenInclude(x => x.FileActivity)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        FileNo = x.HblEntry.FileGuid.FileNo,
                        ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                        hblNo = x.HblEntry.Hblno,
                        Id = x.HblEntry.FileGuid.Id,
                        UserId = x.User.UserName,
                        hblCount = x.HblEntry.FileGuid.Hblcount,
                        StartTime = x.StartTime
                    });
            }
            else
            {
                query = _ctx.FileActivity.Include(x => x.ActivityMaster).Include(x => x.FileEntry).ThenInclude(x => x.User)
                    .Select(x => new FileActivityDataList
                    {
                        ActivityId = x.ActivityMaster.Name,
                        BasedOn = x.ActivityMaster.BasedOn,
                        Comment = x.Comment,
                        CurrentStatus = x.CurrentStatus,
                        EndTime = x.EndTime,
                        EnterDate = x.EnterDate,
                        FileNo = x.FileEntry.FileNo,
                        ContainerNo = x.FileEntry.ContainerNo,
                        Id = x.FileId,
                        UserId = x.FileEntry.User.UserName,
                        hblCount = x.FileEntry.Hblcount,
                        StartTime = x.StartTime
                    });
            }

            // Apply filters
            if (!string.IsNullOrEmpty(activityType) && activityType != "all" && activityType != "--select--")
                query = query.Where(x => x.BasedOn == activityType.Trim());

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--")
                query = query.Where(x => x.ActivityId == activity.Trim());

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--select--")
                query = query.Where(x => x.CurrentStatus == status.Trim());
            else
                query = query.Where(x => x.CurrentStatus != "Completed");

            // Sorting
            query = query.OrderBy($"{sortColumn} {sortColumnDirection}");

            // Pagination
            var totalRecord = query.Count();
            var data = query.Skip(skip).Take(pageSize).ToList();

            var returnObj = new
            {
                draw = draw,
                recordsTotal = totalRecord,
                recordsFiltered = totalRecord, // Filtered records are the same as total records due to in-memory filtering
                data = data,
            };

            return Json(returnObj);
        }

        public IActionResult GetActivityHBLData(string fileNo, string activityId, string status)
        {
            var fileId = _ctx.FileEntry.Where(x => x.FileNo == fileNo).Select(x => x.Id).FirstOrDefault();

            var hblEntry = (from FE in _ctx.FileEntry join HE in _ctx.HblEntry on FE.Id equals HE.FileGuidId join hbl in _ctx.HblActivity on HE.Id equals hbl.HblId
                            select new HBLActivityDataList
                            {
                                Id = HE.Id,
                                Hblno = HE.Hblno,
                                FileGuidId = HE.FileGuidId,
                                IsDap = HE.IsDap == true ? "Yes" : "No",
                                CreatedDate = HE.CreatedDate,
                                BasedOn = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(y => y.Id == hbl.ActivityId && y.IsActive == true && y.ThreadMaster.IsActive == true).Select(x => x.BasedOn).FirstOrDefault(),
                                CreatedBy = _ctx.User.Where(y => y.Id == HE.CreatedBy && y.IsActive == true).Select(y => y.UserName).FirstOrDefault(),
                                Comment = hbl.Comment,
                                CurrentStatus = hbl.CurrentStatus,
                                StartTime = hbl.StartTime,
                                EndTime = hbl.EndTime,
                                EnterBy = hbl.EnterBy,
                                ActivityId = _ctx.HblActivity.Where(y => y.ActivityId == hbl.ActivityId).Select(y => y.ActivityMaster.Name).FirstOrDefault(),
                            }).ToList();

            if (activityId == "File Processing Status")
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == "HBL Status").ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.FileGuidId == fileId && x.ActivityId == activityId).ToList();
            }
            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--")
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus == status.Trim()).ToList();
            }
            else
            {
                hblEntry = hblEntry.Where(x => x.CurrentStatus != "Completed").ToList();
            }

            return Json(hblEntry);
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblId)
        {
            ViewData["hblActivityList"] = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.HblId == hblId && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => new HBLActivityDataList
            {
                Id = x.Id,
                Hblno = x.HblEntry.Hblno == null ? "" : x.HblEntry.Hblno,
                HBLType = x.HblEntry.HBLType == null ? "" : x.HblEntry.HBLType,
                ActivityId = x.ActivityMaster.Name,
                EndTime = x.EndTime,
                CurrentStatus = x.CurrentStatus,
                Comment = x.Comment == null ? "" : x.Comment,
                EnterBy = x.User.CitrixId == null ? "" : x.User.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivityData(string hblno, string hbl)
        {
            var hblact = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Include(x => x.User).Where(x => x.HblEntry.Hblno == hblno && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();
            List<HBLActivityDataList> hblActivityLog = new List<HBLActivityDataList>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityDataList
                {
                    Hblno = hblno == null ? "" : hblno,
                    ActivityId = item.ActivityMaster.Name == null ? "" : item.ActivityMaster.Name,
                    EndTime = item.EndTime,
                    CurrentStatus = item.CurrentStatus,
                    EnterBy = item.User.CitrixId,
                });
            }
            return Json(hblActivityLog);
        }

        public IActionResult GetActivityType(string fileType)
        {

            ViewData["ActivityMaster"] = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            return Json(activity);
        }

        [HttpPost]
        public IActionResult HBLSubmit(HBLActivityDataList model, string fileType, string activityId, string status, DateTime startDate)
        {
            var activity = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == fileType && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var hblId = _ctx.HblEntry.Where(x => x.Hblno == model.Hblno).Select(x => x.Id).FirstOrDefault();
            var hblActivityId = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.HblId == hblId && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).Select(x => x.Id).FirstOrDefault();
            HblActivity hblActivity = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.Id == model.Id.Trim() && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).FirstOrDefault();
            var hblActivityList = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.User).Include(x => x.ActivityMaster).ThenInclude(x => x.ThreadMaster).Where(x => x.HblEntry.FileGuidId == model.FileGuidId && x.ActivityMaster.IsActive == true && x.User.IsActive == true && x.ActivityMaster.ThreadMaster.IsActive == true).ToList();
            if (fileType == "HBL")
            {
                var hbllog = _ctx.HBLHistoryLog.Add(new HBLHistoryLog
                {
                    HBLActivityId = hblActivityId,
                    CurrentStatus = model.CurrentStatus,
                    Comment = model.Comment,
                    EnterBy = model.EnterBy,
                    StartTime = startDate,
                    EndTime = model.EndTime,
                    EnterDate = model.CreatedDate,
                });
                _ctx.SaveChanges();

                hblActivity.CurrentStatus = model.CurrentStatus;
                hblActivity.Comment = model.Comment;
                hblActivity.StartTime = startDate;
                hblActivity.EndTime = DateTime.Now.ToUniversalTime();
                _ctx.HblActivity.Update(hblActivity);
                _ctx.SaveChanges();

                if (model.FileGuidId != null)
                {
                    if (hblActivityList != null)
                    {
                        foreach (var hbl in hblActivityList)
                        {
                            var hblStatus = hblActivityList.Where(x => x.CurrentStatus != "Completed").Count();
                            if (hblStatus == 0)
                            {
                                var fileActivity = _ctx.FileActivity.Where(x => x.FileId == model.FileGuidId).FirstOrDefault();
                                fileActivity.CurrentStatus = model.CurrentStatus;
                                fileActivity.Comment = "All Hbl in this file are completed.";
                                fileActivity.StartTime = startDate;
                                fileActivity.EndTime = DateTime.Now.ToUniversalTime();
                                _ctx.FileActivity.Update(fileActivity);
                                _ctx.SaveChanges();
                            }
                        }
                    }
                }
                return Json("Success");
            }
            else
            {
                return Json("Failed");
            }
        }

        [HttpPost]
        public JsonResult UpdateData(string? columnName, string? editedValue, string? containerId, string? fileId, string? fileActivityLogId, string? startDateTime)
        {
            var file = _ctx.FileEntry.SingleOrDefault(x => x.Id == fileId);
            if (file == null) return Json("File not found.");
            DateTime date = Convert.ToDateTime(startDateTime).ToUniversalTime();

            switch (columnName)
            {
                case "etaAtPod":
                    file.EtaAtPod = Convert.ToDateTime(editedValue).ToUniversalTime();
                    break;
                case "containerNo":
                    if (_ctx.FileEntry.Any(x => x.FileNo == file.FileNo && x.ContainerNo == editedValue))
                        return Json("Duplicate Container in Same File.");
                    file.ContainerNo = editedValue;
                    break;
                case "shippingLine":
                    file.ShippingLine = editedValue;
                    break;
                case "hblcount":
                    file.Hblcount = editedValue;
                    break;
                case "isEdi":
                    if (new[] { "IsEdi", "GIM", "Pending" }.Contains(editedValue))
                        file.IsEdi = editedValue;
                    break;
                case "pol":
                    file.Pol = editedValue;
                    break;
                case "fileNo":
                    if (_ctx.FileEntry.Any(x => x.FileNo == editedValue))
                        return Json("Duplicate File.");
                    file.FileNo = editedValue;
                    break;
                default:
                    return Json("Invalid column name.");
            }

            _ctx.FileEntry.Update(file);
            _ctx.SaveChanges();
            return Json("Success");
        }
        public JsonResult UpdateIsLDAP(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsLDAP = master.IsLDAP != null ? !master.IsLDAP : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsLDAP == true ? master.UserName + " LDAP Active!" : master.UserName + " LDAP InActive!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        
        public JsonResult ActivateThread(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ThreadMaster master = _ctx.ThreadMaster.Where(x => x.Id.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.ThreadMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Thread Active!" : master.Name + " Thread InActive!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        
        public JsonResult ActivateActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _ctx.ActivityMaster.Where(x => x.Id.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.ActivityMaster.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.Name + " Activity Active!" : master.Name + " Activity InActive!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        
        public JsonResult ActivateUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.User.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.User.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? master.CitrixId + " User Active!" : master.CitrixId + " User InActive!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
        public JsonResult DeleteUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                User master = _ctx.User.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
                if (master != null)
                {
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _ctx.User.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsDelete == true ? master.CitrixId + " User Delete!" : master.CitrixId + " User Restore!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public JsonResult UpdateIsReset(string Id)
        {
            string message = "";
            User master = _ctx.Users.Where(x => x.CitrixId.ToLower() == Id.ToLower()).FirstOrDefault();
            if (Id != null)
            {
                if (master != null)
                {
                    master.IsReset = master.IsReset != null ? !master.IsReset : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsReset == true ? master.UserName + " Password Unset!" : master.UserName + " Password Reset!";
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(new { Message = message, UserName = master.UserName, CitrixId = master.CitrixId, UserId = master.Id });
        }

        [Authorize(Roles = "Supervisor,Manager,Admin")]
        public ActionResult Reports()
        {
            return View();
        }

        ////Report download
        [HttpPost]
        public ActionResult Reports(ReportViewModel report)
        {
            DataTable dt = CreateDataTable(report.ReportType);
            DataTable dt1 = CreateDataTable(report.ReportType);
            var startDate = report.start_date;
            var endDate = report.end_date;
            const string ISTTimeZoneId = "India Standard Time";
            var istTimeZone = TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId);

            if (report.start_date == null || report.end_date == null)
            {
                ViewBag.ErrorMessage = "Please Select Date";
                return View();
            }

            if (report.ReportType == "File")
            {
                var fileactivtydata = GetFileActivityData(report.DateType, startDate, endDate);
                var fileactivtyHistory = GetFileHistoryData(report.DateType, startDate, endDate);
                var fileactivtydataList = fileactivtydata.Select(x => MapFileReportViewModel(x, istTimeZone)).ToList();
                var fileactivtyHistoryList = fileactivtyHistory.Select(x => MapFileHistoryReportViewModel(x, istTimeZone)).ToList();
                FillDataTable(fileactivtydataList, dt);
                FillDataTable(fileactivtyHistoryList, dt1);

                return ExportToExcel(new List<DataTable> { dt, dt1 }, "File Data Report");
            }
            else if (report.ReportType == "HBL")
            {
                var HBLdata = GetHBLActivityData(report.DateType, startDate, endDate);
                var HBLHistory = GetHBLHistoryData(report.DateType, startDate, endDate);
                var HBLdataList = HBLdata.Select(x => MapHBLReportViewModel(x, istTimeZone)).ToList();
                var HBLHistoryList = HBLHistory.Select(x => MapHBLHistoryReportViewModel(x, istTimeZone)).ToList();
                FillDataTable(HBLdataList, dt);
                FillDataTable(HBLHistoryList, dt1);

                return ExportToExcel(new List<DataTable> { dt, dt1 }, "HBL Data Report");
            }

            return View();
        }

        private DataTable CreateDataTable(string reportType)
        {
            DataTable dt = new DataTable();
            if (reportType == "File")
            {
                dt.Columns.AddRange(new DataColumn[]
                {
                    new DataColumn("Pod"), new DataColumn("EtaAtPod"), new DataColumn("Received Date"), new DataColumn("ContainerNo"),
                    new DataColumn("Pol"), new DataColumn("FileType"), new DataColumn("Hblcount"), new DataColumn("IsEdi"),
                    new DataColumn("Activity"), new DataColumn("Current Status"), new DataColumn("Comment"), new DataColumn("UserName"),
                    new DataColumn("Pages"), new DataColumn("StartDate"), new DataColumn("EndDate"), new DataColumn("FileNo"),
                    new DataColumn("VesselName"), new DataColumn("ShippingLine")
                });
            }
            else if (reportType == "HBL")
            {
                dt.Columns.AddRange(new DataColumn[]
                {
                    new DataColumn("Received Date"), new DataColumn("FileNo"), new DataColumn("ContainerNo"), new DataColumn("HBLNo"),
                    new DataColumn("IsDap"), new DataColumn("Activity"), new DataColumn("Current Status"), new DataColumn("Comment"),
                    new DataColumn("UserName"), new DataColumn("StartDate"), new DataColumn("EndDate")
                });
            }
            return dt;
        }

        private List<FileActivity> GetFileActivityData(string dateType, DateTime startDate, DateTime endDate)
        {
            IQueryable<FileActivity> query = _ctx.FileActivity.Include(x => x.FileEntry).Include(x => x.User).Include(x => x.ActivityMaster);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.FileEntry.CreatedDate != null && x.FileEntry.CreatedDate.Value.Date >= startDate.Date && x.FileEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date && x.EndTime.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date && x.StartTime.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private List<FileHistoryLog> GetFileHistoryData(string dateType, DateTime startDate, DateTime endDate)
        {
            IQueryable<FileHistoryLog> query = _ctx.FileHistoryLog.Include(x => x.FileActivity).Include(x => x.FileActivity.FileEntry).Include(x => x.User).Include(x => x.FileActivity.ActivityMaster);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.FileActivity.FileEntry.CreatedDate != null && x.FileActivity.FileEntry.CreatedDate.Value.Date >= startDate.Date && x.FileActivity.FileEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date && x.EnterEndDate.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date && x.EnterStartDate.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private List<HblActivity> GetHBLActivityData(string dateType, DateTime startDate, DateTime endDate)
        {
            IQueryable<HblActivity> query = _ctx.HblActivity.Include(x => x.HblEntry).Include(x => x.HblEntry.FileGuid).Include(x => x.ActivityMaster).Include(x => x.User);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.HblEntry.CreatedDate != null && x.HblEntry.CreatedDate.Value.Date >= startDate.Date && x.HblEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.EndTime != null && x.EndTime.Value.Date >= startDate.Date && x.EndTime.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.StartTime != null && x.StartTime.Value.Date >= startDate.Date && x.StartTime.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private List<HBLHistoryLog> GetHBLHistoryData(string dateType, DateTime startDate, DateTime endDate)
        {
            IQueryable<HBLHistoryLog> query = _ctx.HBLHistoryLog.Include(x => x.HblActivity).Include(x => x.HblActivity.HblEntry).Include(x => x.HblActivity.HblEntry.FileGuid).Include(x => x.HblActivity.ActivityMaster).Include(x => x.User);

            if (dateType == "ReceivedDate")
                query = query.Where(x => x.HblActivity.HblEntry.CreatedDate != null && x.HblActivity.HblEntry.CreatedDate.Value.Date >= startDate.Date && x.HblActivity.HblEntry.CreatedDate.Value.Date <= endDate.Date);
            else if (dateType == "EndDate")
                query = query.Where(x => x.EnterEndDate != null && x.EnterEndDate.Value.Date >= startDate.Date && x.EnterEndDate.Value.Date <= endDate.Date);
            else
                query = query.Where(x => x.EnterStartDate != null && x.EnterStartDate.Value.Date >= startDate.Date && x.EnterStartDate.Value.Date <= endDate.Date);

            return query.ToList();
        }

        private FileReportViewModel MapFileReportViewModel(FileActivity x, TimeZoneInfo istTimeZone)
        {
            return new FileReportViewModel
            {
                POD =  x.FileEntry.Pod,
                ETA = x.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                ReceivedDate = x.FileEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                ContainerNo = x.FileEntry.ContainerNo,
                POL = x.FileEntry.Pol,
                FileType = x.FileEntry.FileType,
                HBLCount = x.FileEntry.Hblcount,
                IsEdi = x.FileEntry.IsEdi,
                Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.UserId != null ? x.User.CitrixId : "",
                Pages = x.Pages,
                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.FileEntry.FileNo,
                VesselName = x.FileEntry.VesselName,
                ShippingLine = x.FileEntry.ShippingLine,
            };
        }

        private FileReportViewModel MapFileHistoryReportViewModel(FileHistoryLog x, TimeZoneInfo istTimeZone)
        {
            return new FileReportViewModel
            {
                POD = x.FileActivity.FileEntry.Pod,
                ETA = x.FileActivity.FileEntry.EtaAtPod.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.EtaAtPod.Value, istTimeZone) : (DateTime?)null,
                ReceivedDate = x.FileActivity.FileEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.FileEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                ContainerNo = x.FileActivity.FileEntry.ContainerNo,
                POL = x.FileActivity.FileEntry.Pol,
                FileType = x.FileActivity.FileEntry.FileType,
                HBLCount = x.FileActivity.FileEntry.Hblcount,
                IsEdi = x.FileActivity.FileEntry.IsEdi,
                Activity = x.FileActivity.ActivityId != null ? x.FileActivity.ActivityMaster.Name : "",
                Status = x.FileActivity.CurrentStatus != null ? x.FileActivity.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.FileActivity.UserId != null ? x.FileActivity.User.CitrixId : "",
                Pages = x.FileActivity.Pages,
                StartDate = x.FileActivity.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.FileActivity.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.FileActivity.EndTime.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.FileActivity.FileEntry.FileNo,
                VesselName = x.FileActivity.FileEntry.VesselName,
                ShippingLine = x.FileActivity.FileEntry.ShippingLine,
            };
        }

        private HBLReportViewModel MapHBLReportViewModel(HblActivity x, TimeZoneInfo istTimeZone)
        {
            return new HBLReportViewModel
            {
                ReceivedDate = x.HblEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.HblEntry.FileGuid.FileNo,
                ContainerNo = x.HblEntry.FileGuid.ContainerNo,
                HBLNo = x.HblEntry.Hblno,
                IsDap = x.HblEntry.IsDap,
                Activity = x.ActivityId != null ? x.ActivityMaster.Name : "",
                Status = x.CurrentStatus != null ? x.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.User != null ? x.User.CitrixId : "",
                StartDate = x.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndTime.Value, istTimeZone) : (DateTime?)null,
            };
        }

        private HBLReportViewModel MapHBLHistoryReportViewModel(HBLHistoryLog x, TimeZoneInfo istTimeZone)
        {
            return new HBLReportViewModel
            {
                ReceivedDate = x.HblActivity.HblEntry.CreatedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.HblEntry.CreatedDate.Value, istTimeZone) : (DateTime?)null,
                FileNo = x.HblActivity.HblEntry.FileGuid.FileNo,
                ContainerNo = x.HblActivity.HblEntry.FileGuid.ContainerNo,
                HBLNo = x.HblActivity.HblEntry.Hblno,
                IsDap = x.HblActivity.HblEntry.IsDap,
                Activity = x.HblActivity.ActivityId != null ? x.HblActivity.ActivityMaster.Name : "",
                Status = x.HblActivity.CurrentStatus != null ? x.HblActivity.CurrentStatus : "",
                Comment = x.Comment ?? "",
                User = x.User != null ? x.User.CitrixId : "",
                StartDate = x.HblActivity.StartTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.StartTime.Value, istTimeZone) : (DateTime?)null,
                EndDate = x.HblActivity.EndTime.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.HblActivity.EndTime.Value, istTimeZone) : (DateTime?)null,
            };
        }

        private void FillDataTable(IEnumerable<object> data, DataTable dt)
        {
            foreach (var item in data)
            {
                var values = item.GetType().GetProperties().Select(p => p.GetValue(item, null)).ToArray();
                dt.Rows.Add(values);
            }
        }

        private ActionResult ExportToExcel(List<DataTable> dataTables, string fileName)
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                for (int i = 0; i < dataTables.Count; i++)
                {
                    wb.Worksheets.Add(dataTables[i], $"Sheet{i + 1}");
                }
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", $"{fileName}-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx");
                }
            }
        }

        ///Add File
        [Authorize(Roles = "Admin,Supervisor,Manager")]
        [HttpGet]
        public IActionResult EditFile(string id)
        {
            var query = _ctx.Set<FileEntryViewModel>().FromSqlRaw("SELECT * FROM vw_AdminDashboardViewModels").AsQueryable();
            var data = query.Where(x => x.Id == id).AsQueryable();
            ViewData["EditFile"] = data.FirstOrDefault();
            ViewData["Country"] = _ctx.LocationMaster.OrderBy(x => x.Name).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult EditFile(FileEntryViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var act = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => x.BasedOn == "File" && x.ThreadMaster.Name == "HBL User" && x.IsActive == true && x.ThreadMaster.IsActive == true).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var act1 = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => (x.Name.ToUpper() == "DV" && x.BasedOn == "File") || (x.Name.ToUpper() == "DIGIVIEW" && x.BasedOn == "File")).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var act2 = _ctx.ActivityMaster.Include(x => x.ThreadMaster).Where(x => (x.Name.ToUpper() == "NOA" && x.BasedOn == "File") || (x.Name.ToUpper() == "NOA/DO" && x.BasedOn == "File")).OrderBy(x => x.Sequence).ThenBy(x => x.Name).ToList();
            var activities = act.Union(act1).Union(act2).Distinct().ToList();
            var present = _ctx.FileEntry.Where(x => x.Id == model.Id).FirstOrDefault();
            if (present != null)
            {
                present.FileNo = model.FileNo != null ? model.FileNo : null;
                present.ContainerNo = model.ContainerNo != null ? model.ContainerNo : null;
                present.IsEdi = model.IsEdi != null ? model.IsEdi : null;
                present.Pol = model.Pol != null ? model.Pol : null;
                present.Pod = model.Pod != null ? model.Pod : null;
                present.Hblcount = model.Hblcount != null ? model.Hblcount : null;
                present.ActualHblcount = model.ActualHblcount != null ? model.ActualHblcount : null;
                present.EtaAtPod = model.EtaAtPod != null ? Convert.ToDateTime(model.EtaAtPod).ToUniversalTime() : null;
                //present.Status = null;
                present.CreatedDate = model.CreatedDate != null ? Convert.ToDateTime(model.CreatedDate.Value.Date).ToUniversalTime() : DateTime.UtcNow.Date;
                present.CreatedBy = userid;
                present.FileType = model.FileType != null ? model.FileType : null;
                present.ShippingLine = model.ShippingLine != null ? model.ShippingLine : null;
            }
            _ctx.FileEntry.Update(present);
            _ctx.SaveChanges();
            return Json("Update");
        }
    }
}


