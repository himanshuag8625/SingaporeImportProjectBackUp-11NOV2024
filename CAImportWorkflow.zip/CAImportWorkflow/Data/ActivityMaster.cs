﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public partial class ActivityMaster
    {
        public string Id { get; set; } =Guid.NewGuid().ToString();
        public string Name { get; set; }
        public string BasedOn { get; set; }
        public int? Sequence { get; set; } = 999;
        public bool IsActive { get; set; }
        public string ThreadId { get; set; }

        [ForeignKey("ThreadId")]
        public ThreadMaster ThreadMaster { get; set; }

    }
}
