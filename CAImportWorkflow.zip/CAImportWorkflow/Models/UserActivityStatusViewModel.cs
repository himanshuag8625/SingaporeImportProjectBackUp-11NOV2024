﻿namespace CAImportWorkflow.Models
{
    public class UserActivityStatusViewModel
    {
        public UserActivityStatusViewModel()
        {
            GetFileActivityStatus = new List<FileActivityStatusList>();
            GetHBLActivityStatus = new List<HBLActivityStatusList>();
            GetUserStatusList = new List<UserStatusList>();
        }
        public List<FileActivityStatusList> GetFileActivityStatus  { get; set; }
        public List<HBLActivityStatusList> GetHBLActivityStatus { get; set; }
        public List<UserStatusList> GetUserStatusList { get; set; }
        public List<FileCount> FileCount { get; set; }

    }
    public class UserStatusList
    {
        public string UserId { get; set; }
        public string Activity { get; set; }
        public int WIP { get; set; }
        public int Query { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }
        public int? Total { get; set; }
        public List<FileActivityStatusList> GetFileActivityStatus { get; set; }
        public List<HBLActivityStatusList> GetHBLActivityStatus { get; set; }
    }
    public class FileActivityStatusList
    {
        public string Activity { get; set; }
        public string UserId { get; set; }
        public string ThreadId { get; set; }
        public string ActivityType { get; set; }
        public int WIP { get; set; }
        public int Query { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }
        public int? Total { get; set; }
    }
    public class FileStatusList
    {
        public string Activity { get; set; }
        public int WIP { get; set; }
        public int Query { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }
        public int? Total { get; set; }
    }
    public class HBLActivityStatusList
    {
        public string Activity { get; set; }
        public string UserId { get; set; }
        public string ThreadId { get; set; }
        public string ActivityType { get; set; }
        public int WIP { get; set; }
        public int Query { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }
        public int? Total { get; set; }
    }
    public class HBLStatusList
    {
        public string Activity { get; set; }
        public int WIP { get; set; }
        public int Query { get; set; }
        public int Pending { get; set; }
        public int Completed { get; set; }
        public int CompletedWithQuery { get; set; }
        public int? Total { get; set; }
    }
    public class FileCount
    {

        public string ActivityId { get; set; }
        public string Status { get; set; }
        public int? Count { get; set; }
    }
}
