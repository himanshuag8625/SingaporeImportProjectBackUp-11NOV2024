﻿namespace CAImportWorkflow.Models
{
    public class FileReportViewModel
    {
        public string? POD { get; set; }
        public DateTime? ETA { get; set; }
        public DateTime? ReceivedDate { get; set; }
        public string? ContainerNo { get; set; }
        public string? POL { get; set; }
        public string? FileType { get; set; }
        public string? HBLCount { get; set; }
        public string? IsEdi { get; set; }
        public string? Activity { get; set; }
        public string? Status { get; set; }
        public string? Comment { get; set; }
        public string? User { get; set; }
        public int? Pages { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? FileNo { get; set; }
        public string? VesselName { get; set; }
        public string? ShippingLine { get; set; }

    }
}
