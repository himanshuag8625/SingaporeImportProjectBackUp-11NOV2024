﻿namespace CAImportWorkflow.Models
{
    public class UpdateThreadModel
    {
        public string? UserId { get; set; }
        public List<ThreadList>? ThreadList { get; set; }
    }
    public class ThreadList
    {
        public string? ThreadId { get; set; }
    }
}
