﻿namespace CAImportWorkflow.Models
{
    public class HBLReportViewModel
    {
        public DateTime? ReceivedDate { get; set; }
        public string? FileNo { get; set; }
        public string? ContainerNo { get; set; }
        public string? HBLNo { get; set; }
        public bool? IsDap { get; set; }
        public string? Activity { get; set; }
        public string? Status { get; set; }
        public string? Comment { get; set; }
        public string? User { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
